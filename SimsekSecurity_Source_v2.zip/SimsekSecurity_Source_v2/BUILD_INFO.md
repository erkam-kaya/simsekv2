# Simsek HIPS - Build Information

## Build Artifacts

### Executable Files
- **Service**: `Simsek.Service\bin\Debug\net8.0\Simsek.Service.exe`
- **UI**: `Simsek.UI\bin\Debug\net8.0-windows\Simsek.UI.exe`

### Helper Scripts
- **run_as_admin.ps1** - Run existing build as administrator
- **build_and_run_admin.ps1** - Build and run as administrator
- **cleanup_db.ps1** - Clean database logs
- **add_sample_data.ps1** - Add sample attack logs

## How to Build

```powershell
# Clean build
dotnet clean
dotnet build

# Or use the script
.\build_and_run_admin.ps1
```

## How to Run

### Option 1: Using Script (Recommended)
```powershell
.\run_as_admin.ps1
```

### Option 2: Manual
```powershell
# Start Service
Start-Process -FilePath ".\Simsek.Service\bin\Debug\net8.0\Simsek.Service.exe" -Verb RunAs -WindowStyle Hidden

# Start UI
Start-Process -FilePath ".\Simsek.UI\bin\Debug\net8.0-windows\Simsek.UI.exe" -Verb RunAs
```

## Recent Changes (2026-02-08)

1. ✅ Fixed Live Logs crash (XAML icon names)
2. ✅ Fixed empty log columns (data mapping)
3. ✅ Added database management buttons
4. ✅ Added firewall cleanup on blacklist removal
5. ✅ Created admin run scripts

## Dependencies

- .NET 8.0
- System.Data.SQLite
- MaterialDesignThemes.Wpf
- LiveCharts.Wpf
- H.Pipes

## Database Location

`%ProgramData%\SimsekSecurity\SimsekV2.db`
