# Quick Setup Guide - Simsek Security V2

## ADIM 1: Profil Fotoğrafını Ekle

1. **Fotoğrafınızı kopyalayın**:
   ```powershell
   # Masaüstünüzdeki fotoğrafı Resources klasörüne kopyalayın
   Copy-Item "C:\Users\ErkamKaya\Desktop\[FOTOGRAF_ADI].jpg" "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek.UI\Resources\profile_photo.jpg"
   ```

2. **Uygulamayı yeniden derleyin**:
   ```powershell
   cd C:\Users\ErkamKaya\source\repos\SimsekSecurity
   dotnet build Simsek.UI\Simsek.UI.csproj
   ```

## ADIM 2: Veritabanını Sıfırla

1. **Uygulamayı kapatın** (çalışıyorsa)

2. **Reset scriptini çalıştırın**:
   ```powershell
   cd C:\Users\ErkamKaya\source\repos\SimsekSecurity
   .\reset_database.ps1
   ```

3. **'RESET' yazın** ve Enter'a basın

## ADIM 3: Uygulamayı Çalıştır

```powershell
cd C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek.UI\bin\Debug\net8.0-windows
.\Simsek.UI.exe
```

## Kontrol Listesi

- [ ] Profil fotoğrafı `Resources\profile_photo.jpg` konumunda
- [ ] Uygulama yeniden derlendi
- [ ] Reset script çalıştırıldı
- [ ] Veritabanı sıfırlandı
- [ ] Uygulama başlatıldı
- [ ] HAKKINDA sekmesinde fotoğraf görünüyor
- [ ] Dashboard'da 0 saldırı görünüyor
- [ ] SMTP ayarları boş
