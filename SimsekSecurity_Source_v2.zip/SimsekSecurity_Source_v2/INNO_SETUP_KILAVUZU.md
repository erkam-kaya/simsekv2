# Inno Setup - Kurulum Talimatları

## ✅ Kontrol Listesi

Inno Setup ile installer oluşturmadan önce:

- [x] `Simsek_Setup.iss` dosyası güncel
- [x] Service dosyaları `Publish\Service\` klasöründe
- [x] UI dosyaları `Publish\UI\` klasöründe
- [ ] Profil fotoğrafı eklendi ve uygulama derlendi
- [ ] Veritabanı sıfırlandı (test verileri temizlendi)

## 📋 Inno Setup Script Özeti

**Dosya:** `C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek_Setup.iss`

### Temel Ayarlar
- **Uygulama Adı:** Simsek Security
- **Versiyon:** 2.0
- **Yayıncı:** Erkam KAYA
- **Kurulum Dizini:** `C:\Program Files\Simsek Security\`
- **Dil:** Türkçe
- **Çıktı:** `SimsekSecurity_Setup_v2.0.exe`

### Kurulum Yapılanması

#### 1. Dosya Konumları
```
Publish\UI\*           → {app}\              (Ana uygulama)
Publish\Service\*      → {app}\Service\      (Windows servisi)
```

#### 2. Servis Yönetimi
- **Kurulum sırasında:**
  - Mevcut servis varsa durdurulur ve silinir
  - Yeni servis oluşturulur: `SimsekService`
  - Otomatik başlatma ayarlanır
  - Servis başlatılır

- **Kaldırma sırasında:**
  - Servis durdurulur
  - Servis silinir
  - Türkçe onay mesajı gösterilir
  - Veritabanı korunur (`C:\ProgramData\SimsekSecurity\`)

#### 3. Kısayollar
- Start Menu: Simsek Security
- Masaüstü: Opsiyonel (kullanıcı seçimi)

### Önemli Özellikler

✅ **Servis Kontrolü:** Kurulumdan önce mevcut servis kontrol edilir
✅ **Hata Yönetimi:** ServiceExists() fonksiyonu ile güvenli kurulum
✅ **Türkçe Arayüz:** Tüm mesajlar Türkçe
✅ **Kaldırma Onayı:** Kullanıcıya özel onay mesajı
✅ **Veritabanı Korunur:** Kaldırma sırasında ayarlar silinmez

## 🚀 Installer Oluşturma Adımları

### Yöntem 1: Inno Setup IDE (Önerilen)

1. **Inno Setup Compiler'ı açın**
   - `C:\Program Files (x86)\Inno Setup 6\Compil32.exe`

2. **Script dosyasını açın**
   - File → Open
   - `C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek_Setup.iss`

3. **Compile edin**
   - Build → Compile (veya F9)
   - Hataları kontrol edin

4. **Çıktıyı kontrol edin**
   - Installer: `C:\Users\ErkamKaya\source\repos\SimsekSecurity\SimsekSecurity_Setup_v2.0.exe`

### Yöntem 2: Komut Satırı

```powershell
& "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek_Setup.iss"
```

## ⚠️ Önemli Notlar

### Kurulum Öncesi
1. **Publish klasörlerini kontrol edin:**
   - `Publish\UI\Simsek.UI.exe` var mı?
   - `Publish\Service\Simsek.Service.exe` var mı?
   - Tüm DLL'ler kopyalandı mı?

2. **Profil fotoğrafı:**
   - `Simsek.UI\Resources\profile.jpg` eklenmiş olmalı
   - Uygulama yeniden derlenmiş olmalı

3. **Debug butonları:**
   - "ÖRNEK VERİ" ve "TEMİZLE" butonları kaldırıldı ✅
   - Yanlışlıkla test verisi eklenmeyecek

### Test Etme
1. **Temiz bir makinede test edin:**
   - Installer'ı çalıştırın
   - Servisin başladığını kontrol edin
   - Uygulamayı açın
   - Dashboard'da 0 saldırı olduğunu doğrulayın
   - Profil fotoğrafının göründüğünü kontrol edin

2. **Güncelleme testi:**
   - Mevcut versiyonu kaldırın
   - Yeni installer'ı çalıştırın
   - Veritabanının korunduğunu kontrol edin

## 🔧 Sorun Giderme

### "Source file not found" hatası
- `Publish\UI\` ve `Publish\Service\` klasörlerinin dolu olduğundan emin olun
- Projeleri publish edin:
  ```powershell
  dotnet publish Simsek.UI\Simsek.UI.csproj -c Release -o Publish\UI
  dotnet publish Simsek.Service\Simsek.Service.csproj -c Release -o Publish\Service
  ```

### Servis başlamıyor
- Servis yolu kontrol edin: `{app}\Service\Simsek.Service.exe`
- Event Viewer'da hata loglarını kontrol edin
- Manuel başlatmayı deneyin: `sc start SimsekService`

### Installer boyutu çok büyük
- Normal: ~250-300 MB (.NET 8.0 runtime dahil)
- Self-contained olduğu için bu normaldir

## 📝 Versiyon Notları

**v2.0 Değişiklikleri:**
- ✅ Profil fotoğrafı desteği eklendi
- ✅ Debug butonları kaldırıldı (üretim için)
- ✅ Servis yönetimi iyileştirildi
- ✅ Türkçe kaldırma onayı eklendi
- ✅ Veritabanı koruma mekanizması
- ✅ Temiz kurulum (0 test verisi)

## 🎯 Son Kontrol

Installer oluşturmadan önce:

```powershell
# 1. Profil fotoğrafı var mı?
Test-Path "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek.UI\Resources\profile.jpg"

# 2. Publish klasörleri dolu mu?
Get-ChildItem "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Publish\UI" | Measure-Object
Get-ChildItem "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Publish\Service" | Measure-Object

# 3. UI exe var mı?
Test-Path "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Publish\UI\Simsek.UI.exe"

# 4. Service exe var mı?
Test-Path "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Publish\Service\Simsek.Service.exe"
```

Hepsi ✅ ise Inno Setup'ta Compile edebilirsiniz!
