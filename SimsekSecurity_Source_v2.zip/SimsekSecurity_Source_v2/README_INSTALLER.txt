NASIL KURULUM DOSYASI (SETUP) OLUŞTURULUR?
============================================

1. Inno Setup İndirin ve Kurun:
   - https://jrsoftware.org/isdl.php adresinden "Inno Setup" programını indirip bilgisayarınıza kurun (Ücretsizdir).

2. Scripti Açın:
   - Proje klasöründeki `Simsek_Setup.iss` dosyasına çift tıklayın.

3. Derleyin (Compile):
   - Inno Setup açıldığında üst menüden "Build" -> "Compile" seçeneğine tıklayın.
   - Veya kısayol olarak `Ctrl + F9` tuşuna basın.

4. Setup Dosyasını Alın:
   - Derleme bittiğinde proje klasöründe `SimsekSecurity_Setup.exe` adında bir dosya oluşacaktır.
   - İşte bu dosya sizin dağıtıma hazır kurulum dosyanızdır!

NOTLAR:
-------
- Bu kurulum dosyası uygulamayı "Program Files" altına kurar.
- Masaüstüne kısayol oluşturur.
- Arkadaki "SimsekService" hizmetini otomatik olarak Windows Hizmetleri'ne ekler ve başlatır.
- Uygulama kaldırılırken servisi de otomatik olarak durdurur ve siler.
