using System;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace Simsek.Core
{
    public static class AlertManager
    {
        public static async Task SendAlertAsync(ProtectionConfig config, string subject, string body, string attachmentPath = null)
        {
            if (string.IsNullOrEmpty(config.SmtpUser) || string.IsNullOrEmpty(config.ToEmail)) return;

            try
            {
                using (var client = new SmtpClient(config.SmtpHost, config.SmtpPort))
                {
                    client.EnableSsl = config.SmtpSsl;
                    client.Credentials = new NetworkCredential(config.SmtpUser, config.SmtpPass);

                    var mail = new MailMessage
                    {
                        From = new MailAddress(config.FromEmail, "Simsek Security"),
                        Subject = subject,
                        Body = body,
                        IsBodyHtml = false
                    };
                    mail.To.Add(config.ToEmail);
                    
                    if (!string.IsNullOrEmpty(attachmentPath) && System.IO.File.Exists(attachmentPath))
                    {
                        mail.Attachments.Add(new Attachment(attachmentPath));
                    }

                    await client.SendMailAsync(mail);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"MAIL ERROR: {ex.Message}");
            }
        }
    }
}
