﻿using System;

namespace Simsek.Core
{
    [Serializable]
    public class AttackLog
    {
        public DateTime Time { get; set; }

        // KORUNAN SİSTEM BİLGİLERİ
        public string MachineName { get; set; }     // Korunan PC Adı
        public string MachineIp { get; set; }       // Korunan PC IP (Yerel)

        // SALDIRI / OLAY DETAYLARI
        public int EventId { get; set; }            // 4625
        public string EventType { get; set; }       // "RDP Brute Force", "SQL Login Fail"
        public string Service { get; set; }         // RDP, MSSQL, FTP
        public string FullMessage { get; set; }     // Logun içindeki uzun açıklama

        // SALDIRGAN BİLGİLERİ
        public string AttackerIp { get; set; }      // Saldıran IP
        public string AttackerCountry { get; set; } // GeoLocation (TR, US, CN)
        public string TargetUsername { get; set; }  // Denediği Kullanıcı Adı

        // DURUM
        public bool IsSuccess { get; set; }         // Başarılı mı?
        public bool IsBlocked { get; set; }         // Simsek tarafından bloklandı mı?
        public int Id { get; set; }                 // Veritabanı ID
    }
}