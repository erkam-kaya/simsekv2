﻿namespace Simsek.Core
{
    public class Class1
    {

    }
}
