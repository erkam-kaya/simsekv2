using System;
using System.IO;
using System.Text.Json;

namespace Simsek.Core
{
    public static class ConfigManager
    {
        private const string FileName = "simsek_config.json";
        
        // ProgramData altında ortak klasör
        private static string ConfigFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SimsekSecurity");
        private static string FilePath = Path.Combine(ConfigFolder, FileName);

        // Ayarları Yükle (Dosya yoksa varsayılanı getir)
        public static GateConfig Load()
        {
            if (!File.Exists(FilePath)) return new GateConfig();
            try
            {
                string json = File.ReadAllText(FilePath);
                return JsonSerializer.Deserialize<GateConfig>(json) ?? new GateConfig();
            }
            catch { return new GateConfig(); }
        }

        // Ayarları Kaydet (Okunaklı formatta)
        public static void Save(GateConfig config)
        {
            try
            {
                if (!Directory.Exists(ConfigFolder)) Directory.CreateDirectory(ConfigFolder);

                string json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(FilePath, json);
            }
            catch { }
        }

        private const string ProtectionFileName = "simsek_protection.json";
        private static string ProtectionFilePath = Path.Combine(ConfigFolder, ProtectionFileName);

        public static ProtectionConfig LoadProtectionConfig()
        {
            if (!File.Exists(ProtectionFilePath)) return new ProtectionConfig();
            try
            {
                string json = File.ReadAllText(ProtectionFilePath);
                var options = new JsonSerializerOptions 
                { 
                    PropertyNameCaseInsensitive = true,
                    ReadCommentHandling = JsonCommentHandling.Skip,
                    AllowTrailingCommas = true
                };
                return JsonSerializer.Deserialize<ProtectionConfig>(json, options) ?? new ProtectionConfig();
            }
            catch (Exception)
            { 
                return new ProtectionConfig(); 
            }
        }
        
        public static void SaveProtectionConfig(ProtectionConfig config)
        {
            try
            {
                if (!Directory.Exists(ConfigFolder)) Directory.CreateDirectory(ConfigFolder);
                string json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(ProtectionFilePath, json);
            }
            catch { }
        }
    }
}
