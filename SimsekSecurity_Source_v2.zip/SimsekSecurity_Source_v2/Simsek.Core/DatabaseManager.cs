﻿using System;
using System.IO;
using System.Data.SQLite;

namespace Simsek.Core
{
    public static class DatabaseManager
    {
        private const string DbName = "SimsekV2.db";
        private static string DbFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SimsekSecurity");
        private static string ConnectionString = $"Data Source={Path.Combine(DbFolder, DbName)};Version=3;Journal Mode=WAL;";

        public static void Initialize()
        {
            if (!Directory.Exists(DbFolder))
            {
                Directory.CreateDirectory(DbFolder);
            }

            string dbPath = Path.Combine(DbFolder, DbName);

            if (!File.Exists(dbPath))
            {
                SQLiteConnection.CreateFile(dbPath);
            }

            // Wrap entire initialization in retry logic to handle service contention
            ExecuteWithRetry<object>(() =>
            {
                using (var conn = new SQLiteConnection(ConnectionString))
                {
                    conn.Open();
                    
                    // Enable Write-Ahead Logging for concurrency (Fixes UI flicker/0 issue)
                    ExecuteNonQuery(conn, "PRAGMA journal_mode=WAL;");

                    ExecuteNonQuery(conn, @"
                        CREATE TABLE IF NOT EXISTS Modules (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            ModuleName TEXT UNIQUE, 
                            LogType TEXT,
                            LogSource TEXT,
                            DetectionPattern TEXT,
                            BlockLimit INTEGER DEFAULT 7,
                            AlertLimit INTEGER DEFAULT 5,
                            IsActive INTEGER DEFAULT 1
                        )");

                    ExecuteNonQuery(conn, @"
                        CREATE TABLE IF NOT EXISTS AttackLogs (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                            IpAddress TEXT,
                            Country TEXT,
                            Service TEXT,
                            LogDetails TEXT,
                            TargetUsername TEXT,
                            IsBlocked INTEGER DEFAULT 0
                        )");

                    ExecuteNonQuery(conn, @"
                        CREATE TABLE IF NOT EXISTS BannedIps (
                            IpAddress TEXT PRIMARY KEY,
                            Country TEXT,
                            Reason TEXT,
                            BanDate DATETIME DEFAULT CURRENT_TIMESTAMP
                        )");

                    ExecuteNonQuery(conn, @"
                        CREATE TABLE IF NOT EXISTS Settings (
                            Key TEXT PRIMARY KEY, 
                            Value TEXT
                        )");

                    SeedDefaultModules(conn);
                }
                return null;
            }, null, 20);
        }

        public static void CleanupOldLogs(int keepDays = 30)
        {
            try
            {
                using (var conn = new SQLiteConnection(ConnectionString))
                {
                    conn.Open();
                    ExecuteNonQuery(conn, $"DELETE FROM AttackLogs WHERE Timestamp < date('now', '-{keepDays} days')");
                }
            }
            catch { }
        }

        public static void InsertAttackLog(AttackLog log, bool isBlocked = false)
        {
             try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    string sql = @"INSERT INTO AttackLogs (Timestamp, IpAddress, Country, Service, LogDetails, TargetUsername, IsBlocked) 
                                   VALUES (@time, @ip, @country, @service, @details, @targetUser, @blocked)";
                    
                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        // Fix: Store date as string in specific format to match SQLite helpers
                         string dateStr = log.Time.ToString("yyyy-MM-dd HH:mm:ss");
                        cmd.Parameters.AddWithValue("@time", dateStr);
                        cmd.Parameters.AddWithValue("@ip", log.AttackerIp);
                        cmd.Parameters.AddWithValue("@country", log.AttackerCountry);
                        cmd.Parameters.AddWithValue("@service", log.Service);
                        cmd.Parameters.AddWithValue("@details", log.FullMessage);
                        cmd.Parameters.AddWithValue("@targetUser", log.TargetUsername ?? "-");
                        cmd.Parameters.AddWithValue("@blocked", isBlocked ? 1 : 0);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch { }
        }

        private static void SeedDefaultModules(SQLiteConnection conn)
        {
            var cmd = new SQLiteCommand("SELECT COUNT(*) FROM Modules", conn);
            long count = (long)cmd.ExecuteScalar();

            if (count == 0)
            {
                // RDP: EventID 4625 AND LogonType=10 (RemoteInteractive) or 3 (Network - sometimes RDP uses 3 but 10 is specific)
                // Let's use strict 10 for RDP to differentiate from SMB (which is 3)
                InsertModule(conn, "RDP", "EventLog", "Security", "*[System[(EventID=4625)]] and *[EventData[Data[@Name='LogonType']='10']]", 7, 3);
                
                // MSSQL
                InsertModule(conn, "MSSQL", "EventLog", "Application", "EventID=18456", 10, 5);
                
                // IIS
                InsertModule(conn, "IIS", "FileLog", @"C:\inetpub\logs\LogFiles", " 403 ", 50, 20);

                InsertModule(conn, "VPN", "EventLog", "Security", "EventID=6273", 5, 2);
                
                // FTP
                InsertModule(conn, "FTP", "FileLog", @"C:\inetpub\logs\LogFiles\FTPSVC", " 530 ", 10, 5);
                
                // SMB: EventID 4625 AND LogonType=3 (Network)
                InsertModule(conn, "SMB", "EventLog", "Security", "*[System[(EventID=4625)]] and *[EventData[Data[@Name='LogonType']='3']]", 10, 5);

                InsertModule(conn, "MySQL", "FileLog", @"C:\ProgramData\MySQL\MySQL Server 8.0\Data\mysqld.log", "Access denied", 10, 5);
                InsertModule(conn, "OpenSSH", "EventLog", "OpenSSH/Operational", "EventID=4", 5, 3);
            }

            // AUTO-MIGRATION FOR EXISTING DBs
            // Fix RDP Pattern if it is the old generic one
            ExecuteNonQuery(conn, "UPDATE Modules SET DetectionPattern=\"*[System[(EventID=4625)]] and *[EventData[Data[@Name='LogonType']='10']]\" WHERE ModuleName='RDP' AND DetectionPattern='EventID=4625'");
            // Fix SMB Pattern if it is the old generic one
            ExecuteNonQuery(conn, "UPDATE Modules SET DetectionPattern=\"*[System[(EventID=4625)]] and *[EventData[Data[@Name='LogonType']='3']]\" WHERE ModuleName='SMB' AND DetectionPattern='EventID=4625'");
        }

        private static void InsertModule(SQLiteConnection conn, string name, string type, string source, string pattern, int blockLim, int alertLim, int active = 1)
        {
            string sql = @"INSERT INTO Modules 
                          (ModuleName, LogType, LogSource, DetectionPattern, BlockLimit, AlertLimit, IsActive) 
                          VALUES (@name, @type, @src, @pat, @blim, @alim, @act)";

            using (var cmd = new SQLiteCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@type", type);
                cmd.Parameters.AddWithValue("@src", source);
                cmd.Parameters.AddWithValue("@pat", pattern);
                cmd.Parameters.AddWithValue("@blim", blockLim);
                cmd.Parameters.AddWithValue("@alim", alertLim);
                cmd.Parameters.AddWithValue("@act", active);
                cmd.ExecuteNonQuery();
            }
        }

        public static void InsertBannedIp(string ip, string country, string reason)
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    string sql = "INSERT OR REPLACE INTO BannedIps (IpAddress, Country, Reason, BanDate) VALUES (@ip, @country, @reason, @date)";
                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@ip", ip);
                        cmd.Parameters.AddWithValue("@country", country);
                        cmd.Parameters.AddWithValue("@reason", reason);
                        cmd.Parameters.AddWithValue("@date", DateTime.Now);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch { }
        }

        public static void DeleteBannedIp(string ip)
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    string sql = "DELETE FROM BannedIps WHERE IpAddress=@ip";
                    using (var cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@ip", ip);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch { }
        }

        public static List<BannedItem> GetAllBannedIps()
        {
            var list = new List<BannedItem>();
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand("SELECT * FROM BannedIps ORDER BY BanDate DESC", conn);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new BannedItem
                            {
                                Ip = reader["IpAddress"].ToString(),
                                Country = reader["Country"].ToString(),
                                Reason = reader["Reason"].ToString(),
                                BanDate = Convert.ToDateTime(reader["BanDate"])
                            });
                        }
                    }
                }
            }
            catch { }
            return list;
        }


        private static void ExecuteNonQuery(SQLiteConnection conn, string sql)
        {
            using (var cmd = new SQLiteCommand(sql, conn)) { cmd.ExecuteNonQuery(); }
        }

        public static SQLiteConnection GetConnection()
        {
            return new SQLiteConnection(ConnectionString);
        }

        // --- DASHBOARD HELPERS ---
        public static List<AttackLog> GetRecentAttackLogs(int limit)
        {
            return ExecuteWithRetry(() =>
            {
                var list = new List<AttackLog>();
                using (var conn = GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand($"SELECT * FROM AttackLogs ORDER BY Timestamp DESC LIMIT {limit}", conn);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var log = new AttackLog
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Time = Convert.ToDateTime(reader["Timestamp"]),
                                AttackerIp = reader["IpAddress"].ToString(),
                                AttackerCountry = reader["Country"].ToString(),
                                Service = reader["Service"].ToString(),
                                FullMessage = reader["LogDetails"].ToString(),
                                IsBlocked = Convert.ToBoolean(reader["IsBlocked"])
                            };
                            try { log.TargetUsername = reader["TargetUsername"]?.ToString() ?? "-"; } catch { log.TargetUsername = "-"; }
                            list.Add(log);
                        }
                    }
                }
                return list;
            }, new List<AttackLog>());
        }

        public static List<string> GetActiveModuleNames()
        {
            var list = new List<string>();
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand("SELECT ModuleName FROM Modules WHERE IsActive=1", conn);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(reader["ModuleName"].ToString());
                        }
                    }
                }
            }
            catch { }
            return list;
        }

        private static void LogDbError(string msg)
        {
            try
            {
                // Ensure log folder exists before writing
                if (!Directory.Exists(DbFolder))
                {
                    Directory.CreateDirectory(DbFolder);
                }
                
                string logFile = Path.Combine(DbFolder, "db_debug.txt");
                File.AppendAllText(logFile, $"{DateTime.Now}: {msg}\n");
            }
            catch { }
        }

        private static T ExecuteWithRetry<T>(Func<T> action, T defaultValue, int maxRetries = 10)
        {
            for (int i = 0; i < maxRetries; i++)
            {
                try
                {
                    return action();
                }
                catch (SQLiteException ex) when (ex.Message.Contains("locked") || ex.Message.Contains("busy"))
                {
                    LogDbError($"Attempt {i+1} Locked: {ex.Message}");
                    if (i == maxRetries - 1) 
                    {
                         LogDbError($"Max Retries Reached. Returning default.");
                         return defaultValue;
                    }
                    System.Threading.Thread.Sleep(50); // Small delay before retry
                }
                catch (Exception ex)
                {
                    LogDbError($"CRITICAL DB ERROR: {ex.Message}\nStack: {ex.StackTrace}");
                    return defaultValue;
                }
            }
            return defaultValue;
        }

        public static int GetAttackCount24Hours()
        {
            return ExecuteWithRetry(() =>
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    string cutoff = DateTime.Now.AddHours(-24).ToString("yyyy-MM-dd HH:mm:ss");
                    var cmd = new SQLiteCommand("SELECT COUNT(*) FROM AttackLogs WHERE Timestamp >= @cutoff", conn);
                    cmd.Parameters.AddWithValue("@cutoff", cutoff);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }, 0);
        }

        public static List<CountryStats> GetTopCountries(int limit = 5)
        {
            return ExecuteWithRetry(() =>
            {
                var list = new List<CountryStats>();
                using (var conn = GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand($"SELECT Country, COUNT(*) as Count FROM AttackLogs GROUP BY Country ORDER BY Count DESC LIMIT {limit}", conn);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new CountryStats
                            {
                                Name = reader["Country"].ToString(),
                                Count = Convert.ToInt32(reader["Count"])
                            });
                        }
                    }
                }
                return list;
            }, new List<CountryStats>());
        }
    }
}