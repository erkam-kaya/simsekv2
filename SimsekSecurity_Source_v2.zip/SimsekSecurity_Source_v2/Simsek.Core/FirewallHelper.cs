﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Simsek.Core
{
    // WINDOWS FIREWALL İLE KONUŞAN SINIF (V2.0 UYUMLU)
    // Artık sadece IP string listesi değil, detaylı BannedItem listesi kabul eder.
    public static class FirewallHelper
    {
        private const string RuleName = "SIMSEK_BLACKLIST_BLOCK";

        // GÜNCELLEME BURADA: Parametre tipi List<string> yerine List<BannedItem> oldu.
        public static void SyncBlacklist(List<BannedItem> bannedItems)
        {
            try
            {
                System.Diagnostics.Debug.WriteLine($"FirewallHelper: SyncBlacklist called with {bannedItems?.Count ?? 0} items");
                
                // 1. Liste boşsa kuralı sil, rahatlat.
                if (bannedItems == null || bannedItems.Count == 0)
                {
                    System.Diagnostics.Debug.WriteLine("FirewallHelper: No banned items, removing firewall rule");
                    RunCommand($"advfirewall firewall delete rule name=\"{RuleName}\"");
                    return;
                }

                // 2. Nesne listesinden sadece IP stringlerini çekip ayıklıyoruz.
                var uniqueIps = bannedItems
                                .Select(x => x.Ip) // BannedItem içindeki Ip özelliğini al
                                .Where(ip => !string.IsNullOrWhiteSpace(ip))
                                .Distinct()
                                .ToList();

                System.Diagnostics.Debug.WriteLine($"FirewallHelper: {uniqueIps.Count} unique IPs to block");
                
                if (uniqueIps.Count == 0)
                {
                    System.Diagnostics.Debug.WriteLine("FirewallHelper: No valid IPs after filtering");
                    return;
                }

                string remoteIpString = string.Join(",", uniqueIps);
                System.Diagnostics.Debug.WriteLine($"FirewallHelper: IP list: {remoteIpString}");

                // 3. Önce eski kuralı sil
                System.Diagnostics.Debug.WriteLine("FirewallHelper: Deleting old rule");
                RunCommand($"advfirewall firewall delete rule name=\"{RuleName}\"");

                // 4. YENİ KURAL (AGRESİF MOD)
                // Interface=Any, Edge=Yes ile kaçış yok.
                string command = $"advfirewall firewall add rule name=\"{RuleName}\" dir=in action=block protocol=any profile=any interfacetype=any edge=yes enable=yes remoteip=\"{remoteIpString}\"";
                
                System.Diagnostics.Debug.WriteLine($"FirewallHelper: Adding new rule");
                RunCommand(command);
                System.Diagnostics.Debug.WriteLine("FirewallHelper: Firewall rule updated successfully");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"FirewallHelper CRITICAL ERROR: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"Stack Trace: {ex.StackTrace}");
            }
        }

        private static void RunCommand(string args)
        {
            try
            {
                System.Diagnostics.Debug.WriteLine($"FirewallHelper: Running netsh command: {args}");
                
                Process p = new Process();
                p.StartInfo.FileName = "netsh.exe";
                p.StartInfo.Arguments = args;

                // YÖNETİCİ İZNİ
                p.StartInfo.UseShellExecute = true;
                p.StartInfo.Verb = "runas";

                p.StartInfo.CreateNoWindow = true;
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                
                p.Start();
                p.WaitForExit();
                
                int exitCode = p.ExitCode;
                System.Diagnostics.Debug.WriteLine($"FirewallHelper: Command completed with exit code: {exitCode}");
                
                if (exitCode != 0)
                {
                    System.Diagnostics.Debug.WriteLine($"FirewallHelper WARNING: Non-zero exit code, command may have failed");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"FirewallHelper: RunCommand ERROR: {ex.Message}");
            }
        }
    }
}
