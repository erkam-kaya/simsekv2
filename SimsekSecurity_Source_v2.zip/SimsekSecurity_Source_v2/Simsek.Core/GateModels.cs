﻿using System;
using System.Collections.Generic;

namespace Simsek.Core
{
    // V2.0 İÇİN GÜNCELLENMİŞ MODELLER

    [Serializable]
    public class BannedItem
    {
        public string Ip { get; set; }
        public string Country { get; set; }
        public DateTime BanDate { get; set; }
        public string Reason { get; set; }

        public override string ToString() => $"{Ip} ({Country})";
    }

    [Serializable]
    public class GateConfig
    {
        public bool IsGeoWhitelistMode { get; set; } = false;

        public List<string> GeoBlacklist { get; set; } = new List<string>();
        public List<string> GeoWhitelist { get; set; } = new List<string>();

        // KRİTİK DEĞİŞİKLİK: Artık string listesi değil, detaylı nesne listesi!
        public List<BannedItem> IpBlacklist { get; set; } = new List<BannedItem>();
        public List<string> IpWhitelist { get; set; } = new List<string>();

        public bool IsAutoBlockActive { get; set; } = true;
        public int AutoBlockLimit { get; set; } = 7;
    }

    public class SuspiciousIp
    {
        public string IpAddress { get; set; }
        public string Country { get; set; }
        public int FailCount { get; set; }
        public DateTime LastAttemptTime { get; set; }
        public string Service { get; set; }
        public string TargetUser { get; set; } // Hedef alınan kullanıcı adı
    }

    public class ModuleConfigItem
    {
        public int Id { get; set; }
        public string ModuleName { get; set; } = string.Empty;
        public int BlockLimit { get; set; }
        public int AlertLimit { get; set; }
    }

    public class CountryStats
    {
        public string Name { get; set; }
        public int Count { get; set; }
    }
}