using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace Simsek.Core
{
    public class LocalizationManager
    {
        private static LocalizationManager? _instance;
        private static readonly object _lock = new object();
        
        private Dictionary<string, string> _translations = new Dictionary<string, string>();
        private string _currentLanguage = LoadSavedLanguage();
        
        public static LocalizationManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        if (_instance == null)
                        {
                            _instance = new LocalizationManager();
                        }
                    }
                }
                return _instance;
            }
        }
        
        public event Action? LanguageChanged;
        
        public string CurrentLanguage => _currentLanguage;
        
        private LocalizationManager()
        {
            LoadLanguage(_currentLanguage);
        }
        
        public string GetString(string key, string defaultValue = "")
        {
            if (_translations.TryGetValue(key, out string? value))
            {
                return value;
            }
            return string.IsNullOrEmpty(defaultValue) ? key : defaultValue;
        }
        
        public void SetLanguage(string languageCode)
        {
            if (_currentLanguage == languageCode) return;
            
            _currentLanguage = languageCode;
            LoadLanguage(languageCode);
            LanguageChanged?.Invoke();
            
            // Save preference
            try
            {
                string configFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SimsekSecurity");
                Directory.CreateDirectory(configFolder);
                File.WriteAllText(Path.Combine(configFolder, "language.txt"), languageCode);
            }
            catch { }
        }
        
        private void LoadLanguage(string languageCode)
        {
            _translations.Clear();
            
            try
            {
                // Try to load from embedded resources or file system
                string langFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Languages", $"{languageCode}.json");
                
                if (!File.Exists(langFile))
                {
                    // Fallback to Turkish
                    langFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Languages", "tr.json");
                }
                
                if (File.Exists(langFile))
                {
                    string json = File.ReadAllText(langFile);
                    var dict = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
                    if (dict != null)
                    {
                        _translations = dict;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Language load error: {ex.Message}");
            }
        }
        
        public static string LoadSavedLanguage()
        {
            try
            {
                string configFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SimsekSecurity");
                string langFile = Path.Combine(configFolder, "language.txt");
                if (File.Exists(langFile))
                {
                    return File.ReadAllText(langFile).Trim();
                }
            }
            catch { }
            return "tr"; // Default Turkish
        }
    }
}
