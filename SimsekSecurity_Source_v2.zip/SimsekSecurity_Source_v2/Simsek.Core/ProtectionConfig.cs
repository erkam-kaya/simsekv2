﻿using System;

namespace Simsek.Core
{
    [Serializable]
    public class ProtectionConfig
    {
        // SİSTEM & ERİŞİM
        public bool IsRdpActive { get; set; } = true;         // Remote Desktop
        public bool IsSshActive { get; set; } = false;        // SSH Protocol
        public bool IsVpnActive { get; set; } = false;        // MS VPN (RRAS)
        public bool IsRdWebActive { get; set; } = false;      // RD Web Access

        // VERİTABANI
        public bool IsMsSqlActive { get; set; } = true;       // MS-SQL Server
        public bool IsMySqlActive { get; set; } = false;      // MySQL Server

        // WEB & UYGULAMA
        public bool IsIisLoginActive { get; set; } = false;   // IIS Web Login
        public bool IsHttpActive { get; set; } = false;       // HTTP Protocol (Genel)
        public bool IsAspNetActive { get; set; } = false;     // ASP.NET Forms

        // MAİL & TRANSFER
        public bool IsFtpActive { get; set; } = false;        // FTP Protocol
        public bool IsSmtpActive { get; set; } = false;       // SMTP Protocol
        public bool IsPop3Active { get; set; } = false;       // POP3 Protocol
        public bool IsImapActive { get; set; } = false;       // IMAP Protocol

        // İLETİŞİM
        public bool IsVoipActive { get; set; } = false;       // VoIP (SIP Protocol)

        // LOG YOLLARI (Genel Tanımlar)
        public string IisLogPath { get; set; } = @"C:\inetpub\logs\LogFiles";
        public string MySqlLogPath { get; set; } = @"C:\ProgramData\MySQL\MySQL Server 8.0\Data\mysqld.log";

        // SMTP AYARLARI (Bildirimler İçin)
        public string SmtpHost { get; set; } = "smtp.gmail.com";
        public int SmtpPort { get; set; } = 587;
        public string SmtpUser { get; set; } = "";
        public string SmtpPass { get; set; } = "";
        public bool SmtpSsl { get; set; } = true;
        public string FromEmail { get; set; } = "";
        public string ToEmail { get; set; } = "";

        // ALERT SENARYOLARI
        public bool AlertOnBlock { get; set; } = true;
        public bool AlertOnGeoFail { get; set; } = true;
        public bool AlertOnGeoSuccess { get; set; } = false;
        public bool AlertOnCriticalModule { get; set; } = true;

        // Scheduled Tasks
        public string ReportFrequency { get; set; } = "Never"; // Never, Weekly, Monthly
        public string DbMaintenanceFrequency { get; set; } = "Monthly"; // Never, Weekly, Monthly
        public DateTime LastReportDate { get; set; }
        public DateTime LastMaintenanceDate { get; set; }
    }
}