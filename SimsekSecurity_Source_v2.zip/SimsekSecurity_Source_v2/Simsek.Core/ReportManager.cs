using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace Simsek.Core
{
    public static class ReportManager
    {
        public static string GenerateLogListReport(List<AttackLog> logs)
        {
            try
            {
                PdfDocument document = new PdfDocument();
                document.Info.Title = "Simsek Security Log Listesi";
                
                PdfPage page = document.AddPage();
                XGraphics gfx = XGraphics.FromPdfPage(page);
                XFont fontTitle = new XFont("Verdana", 16, XFontStyle.Bold);
                XFont fontHeader = new XFont("Verdana", 9, XFontStyle.Bold);
                XFont fontNormal = new XFont("Verdana", 8, XFontStyle.Regular);

                int y = 40;
                gfx.DrawString("CANLI LOG KAYITLARI LİSTESİ", fontTitle, XBrushes.DarkRed, new XRect(0, y, page.Width, page.Height), XStringFormats.TopCenter);
                y += 30;
                gfx.DrawString($"Dışa Aktarma Tarihi: {DateTime.Now:dd.MM.yyyy HH:mm:ss} | Toplam Kayıt: {logs.Count}", fontNormal, XBrushes.Black, 40, y);
                y += 20;

                // Tablo Başlıkları
                gfx.DrawRectangle(XBrushes.LightGray, 40, y, page.Width - 80, 20);
                gfx.DrawString("ZAMAN", fontHeader, XBrushes.Black, 45, y + 14);
                gfx.DrawString("SERVİS", fontHeader, XBrushes.Black, 140, y + 14);
                gfx.DrawString("IP ADRESİ", fontHeader, XBrushes.Black, 200, y + 14);
                gfx.DrawString("ÜLKE", fontHeader, XBrushes.Black, 300, y + 14);
                gfx.DrawString("HEDEF USER", fontHeader, XBrushes.Black, 350, y + 14);
                y += 25;

                foreach (var log in logs.Take(100)) // Limit increased to 100
                {
                    gfx.DrawString(log.Time.ToString("HH:mm:ss"), fontNormal, XBrushes.Black, 45, y);
                    gfx.DrawString(log.Service, fontNormal, XBrushes.Black, 140, y);
                    gfx.DrawString(log.AttackerIp, fontNormal, XBrushes.Black, 200, y);
                    gfx.DrawString(log.AttackerCountry, fontNormal, XBrushes.Black, 300, y);
                    gfx.DrawString(log.TargetUsername ?? "-", fontNormal, XBrushes.Black, 350, y);
                    
                    y += 15;
                    if (y > page.Height - 50) break;
                }

                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filename = $"Simsek_Log_Export_{DateTime.Now:yyyyMMdd_HHmm}.pdf";
                string fullPath = Path.Combine(desktopPath, filename);

                document.Save(fullPath);
                return fullPath;
            }
            catch (Exception ex)
            {
                throw new Exception("Log PDF oluşturulurken hata: " + ex.Message);
            }
        }

        public static string GenerateSummaryReport(int queryDays = 1)
        {
            try
            {
                // 1. Verileri Çek
                var stats = GetSummaryStats(queryDays);
                string titlePeriod = queryDays == 1 ? "GÜNLÜK" : (queryDays == 7 ? "HAFTALIK" : "AYLIK");

                // 2. PDF Dokümanı Oluştur
                PdfDocument document = new PdfDocument();
                document.Info.Title = $"Simsek Security {titlePeriod} Rapor";

                // Sayfa Ekle
                PdfPage page = document.AddPage();
                XGraphics gfx = XGraphics.FromPdfPage(page);
                XFont fontTitle = new XFont("Verdana", 20, XFontStyle.Bold);
                XFont fontHeader = new XFont("Verdana", 12, XFontStyle.Bold);
                XFont fontNormal = new XFont("Verdana", 10, XFontStyle.Regular);
                XFont fontSmall = new XFont("Verdana", 8, XFontStyle.Regular);

                int y = 50;

                // Başlık
                gfx.DrawString($"ŞİMŞEK SECURITY - {titlePeriod} RAPOR", fontTitle, XBrushes.DarkRed, new XRect(0, y, page.Width, page.Height), XStringFormats.TopCenter);
                y += 40;
                gfx.DrawString($"Rapor Tarihi: {DateTime.Now:dd.MM.yyyy HH:mm}", fontHeader, XBrushes.Black, new XRect(50, y, page.Width, page.Height), XStringFormats.TopLeft);
                y += 30;
                gfx.DrawLine(XPens.Gray, 50, y, page.Width - 50, y);
                y += 20;

                // Özet
                gfx.DrawString($"Toplam Saldırı ({queryDays} gün): {stats.TotalAttacks}", fontHeader, XBrushes.DarkBlue, 50, y);
                y += 20;
                gfx.DrawString($"Toplam Engellenen: {stats.TotalBlocked}", fontHeader, XBrushes.DarkRed, 50, y);
                y += 30;

                // Tablo: En Çok Saldıran Ülkeler
                gfx.DrawString("EN ÇOK SALDIRAN ÜLKELER (TOP 5)", fontHeader, XBrushes.Black, 50, y);
                y += 20;

                foreach (var country in stats.TopCountries)
                {
                    gfx.DrawString($"{country.Key}: {country.Value} saldırı", fontNormal, XBrushes.Black, 70, y);
                    y += 15;
                }
                y += 20;

                // Tablo: Servis Dağılımı
                gfx.DrawString("SERVİS DAĞILIMI", fontHeader, XBrushes.Black, 50, y);
                y += 20;

                foreach (var service in stats.ServiceDistribution)
                {
                    gfx.DrawString($"{service.Key}: {service.Value}", fontNormal, XBrushes.Black, 70, y);
                    y += 15;
                }
                y += 20;

                // YENİ: En Çok Saldıran IP'ler
                gfx.DrawString("EN ÇOK SALDIRAN IP ADRESLERİ (TOP 10)", fontHeader, XBrushes.Black, 50, y);
                y += 20;

                var topIps = GetTopAttackingIPs(10, queryDays);
                foreach (var ip in topIps)
                {
                    gfx.DrawString($"{ip.Key} ({ip.Value} saldırı)", fontSmall, XBrushes.Black, 70, y);
                    y += 12;
                    if (y > page.Height - 100) break; // Sayfa taşmasını önle
                }
                y += 20;

                // YENİ: Son Engellenenler
                if (y < page.Height - 150)
                {
                    gfx.DrawString("SON ENGELLENEN IP'LER (SON 5)", fontHeader, XBrushes.Black, 50, y);
                    y += 20;

                    var recentBlocks = GetRecentBlocks(5);
                    foreach (var block in recentBlocks)
                    {
                        gfx.DrawString($"{block.Ip} - {block.Country} ({block.BanDate:dd.MM HH:mm})", fontSmall, XBrushes.DarkRed, 70, y);
                        gfx.DrawString($"Sebep: {block.Reason}", fontSmall, XBrushes.Gray, 90, y + 10);
                        y += 22;
                        if (y > page.Height - 80) break;
                    }
                }

                // Alt Bilgi
                y = (int)page.Height - 50;
                gfx.DrawString("Bu rapor Simsek Security tarafından otomatik oluşturulmuştur.", new XFont("Verdana", 8, XFontStyle.Italic), XBrushes.Gray, 50, y);

                // Kaydet
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filename = $"Simsek_{titlePeriod}_Rapor_{DateTime.Now:yyyyMMdd_HHmm}.pdf";
                string fullPath = Path.Combine(desktopPath, filename);

                document.Save(fullPath);
                return fullPath;
            }
            catch (Exception ex)
            {
                throw new Exception("PDF oluşturulurken hata: " + ex.Message);
            }
        }

        private static Dictionary<string, int> GetTopAttackingIPs(int limit, int days)
        {
            var result = new Dictionary<string, int>();
            try
            {
                using (var conn = DatabaseManager.GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand($@"
                        SELECT IpAddress, COUNT(*) as AttackCount 
                        FROM AttackLogs 
                        WHERE Timestamp >= date('now', '-{days} days')
                        GROUP BY IpAddress 
                        ORDER BY AttackCount DESC 
                        LIMIT {limit}", conn);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result[reader["IpAddress"].ToString()] = Convert.ToInt32(reader["AttackCount"]);
                        }
                    }
                }
            }
            catch { }
            return result;
        }

        private static List<BannedItem> GetRecentBlocks(int limit)
        {
            var result = new List<BannedItem>();
            try
            {
                using (var conn = DatabaseManager.GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand($@"
                        SELECT IpAddress, Country, Reason, BanDate 
                        FROM BannedIps 
                        ORDER BY BanDate DESC 
                        LIMIT {limit}", conn);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new BannedItem
                            {
                                Ip = reader["IpAddress"]?.ToString() ?? "",
                                Country = reader["Country"]?.ToString() ?? "??",
                                Reason = reader["Reason"]?.ToString() ?? "Bilinmiyor",
                                BanDate = reader["BanDate"] != DBNull.Value ? Convert.ToDateTime(reader["BanDate"]) : DateTime.Now
                            });
                        }
                    }
                }
            }
            catch { }
            return result;
        }

        public static ReportData GetSummaryStats(int days = 1)
        {
            var data = new ReportData();

            try
            {
                using (var conn = DatabaseManager.GetConnection())
                {
                    conn.Open();

                    // Tarih filtresi
                    string timeFilter = $"timestamp >= date('now', '-{days} days')";

                    // Toplam Saldırı
                    using (var cmd = new SQLiteCommand($"SELECT COUNT(*) FROM AttackLogs WHERE {timeFilter}", conn))
                        data.TotalAttacks = Convert.ToInt32(cmd.ExecuteScalar());

                    // Engellenenler
                    using (var cmd = new SQLiteCommand($"SELECT COUNT(*) FROM AttackLogs WHERE {timeFilter} AND IsBlocked=1", conn))
                        data.TotalBlocked = Convert.ToInt32(cmd.ExecuteScalar());

                    // Ülkeler
                    using (var cmd = new SQLiteCommand($"SELECT Country, COUNT(*) as C FROM AttackLogs WHERE {timeFilter} GROUP BY Country ORDER BY C DESC LIMIT 5", conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.TopCountries.Add(reader["Country"].ToString(), Convert.ToInt32(reader["C"]));
                        }
                    }

                    // Servisler
                    using (var cmd = new SQLiteCommand($"SELECT Service, COUNT(*) as C FROM AttackLogs WHERE {timeFilter} GROUP BY Service ORDER BY C DESC", conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            data.ServiceDistribution.Add(reader["Service"].ToString(), Convert.ToInt32(reader["C"]));
                        }
                    }
                }
            }
            catch { }

            return data;
        }

        public class ReportData
        {
            public int TotalAttacks { get; set; }
            public int TotalBlocked { get; set; }
            public Dictionary<string, int> TopCountries { get; set; } = new Dictionary<string, int>();
            public Dictionary<string, int> ServiceDistribution { get; set; } = new Dictionary<string, int>();
        }
    }
}
