﻿using System;
using System.Collections.Generic;

namespace Simsek.Core
{
    [Serializable]
    public class SimsekMessage
    {
        public string Text { get; set; } = string.Empty; // Komut (UPDATE_CONFIG, SALDIRI_VAR)
        public string Data { get; set; } = string.Empty;
        public List<AttackLog> Logs { get; set; } = new List<AttackLog>();

        // YENİ: Ayar Paketi Taşıyıcı
        public ProtectionConfig Config { get; set; }
    }
}