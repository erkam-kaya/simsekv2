using Simsek.Service;

var builder = Host.CreateApplicationBuilder(args);
builder.Services.AddSingleton<ProtectionService>();
builder.Services.AddHostedService<Worker>();

// CRITICAL: Enable Windows Service lifetime
builder.Services.AddWindowsService(options =>
{
    options.ServiceName = "Simsek Security Service";
});

try
{
    var host = builder.Build();
    host.Run();
}
catch (Exception ex)
{
    Console.WriteLine($"FATAL CRASH: {ex}");
    
    // Use CommonApplicationData for crash log (same as database location)
    try
    {
        string logFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "SimsekSecurity");
        Directory.CreateDirectory(logFolder); // Ensure folder exists
        string logPath = Path.Combine(logFolder, "service_crash.log");
        File.WriteAllText(logPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] FATAL CRASH:\n{ex}");
    }
    catch { } // If logging fails, at least we tried
    
    throw;
}
