using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Simsek.Core;
using System.Data.SQLite;

namespace Simsek.Service
{
    public class ProtectionService
    {
        private List<SuspiciousIp> _suspiciousList = new List<SuspiciousIp>();
        private GateConfig _gateConfig = new GateConfig();
        private List<ModuleConfigItem> _modules = new List<ModuleConfigItem>();

        public event Action<AttackLog>? OnAttackDetected;
        public event Action<string>? OnStatusChanged;

        private ProtectionConfig _protectionConfig = new ProtectionConfig();

        public ProtectionService()
        {
            ReloadConfig();
        }

        public void ReloadConfig()
        {
            _gateConfig = ConfigManager.Load();
            _protectionConfig = ConfigManager.LoadProtectionConfig();
            Console.WriteLine($"DEBUG: ReloadConfig - IsRdpActive: {_protectionConfig.IsRdpActive}, IsSshActive: {_protectionConfig.IsSshActive}");
            LoadModulesFromDb();
            FirewallHelper.SyncBlacklist(_gateConfig.IpBlacklist);
            OnStatusChanged?.Invoke("Ayarlar ve Modüller Yenilendi.");
        }

        private void LoadModulesFromDb()
        {
            _modules.Clear();
            try
            {
                using (var conn = DatabaseManager.GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand("SELECT * FROM Modules WHERE IsActive=1", conn);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _modules.Add(new ModuleConfigItem
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                ModuleName = reader["ModuleName"].ToString(),
                                BlockLimit = Convert.ToInt32(reader["BlockLimit"]),
                                AlertLimit = Convert.ToInt32(reader["AlertLimit"])
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                OnStatusChanged?.Invoke($"Modül Yükleme Hatası: {ex.Message}");
            }
        }

        public bool IsServiceActive(string service)
        {
            if (string.IsNullOrEmpty(service)) return true; // Servis belirtilmemişse genel koruma varsay

            // Servis ismini normalize et (Büyük/küçük harf duyarlılığı için)
            string s = service.ToUpperInvariant();
            
            bool result = true;

            if (s.Contains("RDP") || s.Contains("REMOTE DESKTOP")) result = _protectionConfig.IsRdpActive;
            else if (s.Contains("SSH")) result = _protectionConfig.IsSshActive;
            else if (s.Contains("VPN") || s.Contains("RRAS")) result = _protectionConfig.IsVpnActive;
            else if (s.Contains("RDWEB") || s.Contains("RD WEB")) result = _protectionConfig.IsRdWebActive;
            
            else if (s.Contains("SQL") && s.Contains("MS")) result = _protectionConfig.IsMsSqlActive;
            else if (s.Contains("MSSQL")) result = _protectionConfig.IsMsSqlActive;
            else if (s.Contains("MYSQL")) result = _protectionConfig.IsMySqlActive;
            
            else if (s.Contains("IIS") || s.Contains("WEB LOGIN")) result = _protectionConfig.IsIisLoginActive;
            else if (s.Contains("HTTP")) result = _protectionConfig.IsHttpActive;
            else if (s.Contains("ASP.NET") || s.Contains("ASPNET")) result = _protectionConfig.IsAspNetActive;

            else if (s.Contains("FTP")) result = _protectionConfig.IsFtpActive;
            else if (s.Contains("SMTP") || s.Contains("MAIL")) result = _protectionConfig.IsSmtpActive;
            else if (s.Contains("POP3")) result = _protectionConfig.IsPop3Active;
            else if (s.Contains("IMAP")) result = _protectionConfig.IsImapActive;

            else if (s.Contains("VOIP") || s.Contains("SIP")) result = _protectionConfig.IsVoipActive;

            // Bilinmeyen servis ise varsayılan olarak aktif kabul et veya yapılandırmaya göre işlem yap
            return result; 
        }

        public async Task AnalyzeLog(AttackLog log)
        {
            if (!IsServiceActive(log.Service))
            {
                 return;
            }

            DatabaseManager.InsertAttackLog(log);

            OnAttackDetected?.Invoke(log);

            if (!_gateConfig.IsAutoBlockActive) return;

            if (_gateConfig.IpWhitelist.Contains(log.AttackerIp)) return;
            if (_gateConfig.IpBlacklist.Any(x => x.Ip == log.AttackerIp)) return;

            bool shouldBlockGeo = false;
            if (_gateConfig.IsGeoWhitelistMode)
            {
                if (_gateConfig.GeoWhitelist.Count > 0 && !_gateConfig.GeoWhitelist.Contains(log.AttackerCountry)) 
                    shouldBlockGeo = true;
            }
            else
            {
                if (_gateConfig.GeoBlacklist.Contains(log.AttackerCountry)) 
                    shouldBlockGeo = true;
            }

            if (shouldBlockGeo)
            {
                BlockUser(log.AttackerIp, log.AttackerCountry, "Coğrafi Engel");
                
                if (_protectionConfig.AlertOnGeoFail)
                {
                    _ = AlertManager.SendAlertAsync(_protectionConfig, 
                        "Simsek - Coğrafi Erişim Engellendi", 
                        $"IP: {log.AttackerIp}\nÜlke: {log.AttackerCountry}\nServis: {log.Service}\nSebep: Coğrafi Blacklist/Whitelist politikası gereği erişim engellendi.");
                }
                return;
            }

            if (log.IsSuccess && _protectionConfig.AlertOnGeoSuccess)
            {
                if (_gateConfig.IsGeoWhitelistMode && !_gateConfig.GeoWhitelist.Contains(log.AttackerCountry))
                {
                    _ = AlertManager.SendAlertAsync(_protectionConfig,
                        "Simsek - KRİTİK: Kısıtlı Ülkeden Başarılı Giriş",
                        $"DİKKAT! Kısıtlı bir ülkeden ({log.AttackerCountry}) başarılı giriş tespit edildi!\nIP: {log.AttackerIp}\nKullanıcı: {log.TargetUsername}\nServis: {log.Service}");
                }
            }

            // 4. ŞÜPHELİ HAVUZU KONTROLÜ
            var suspect = _suspiciousList.FirstOrDefault(x => x.IpAddress == log.AttackerIp);
            if (suspect == null)
            {
                suspect = new SuspiciousIp
                {
                    IpAddress = log.AttackerIp,
                    FailCount = 1,
                    Country = log.AttackerCountry,
                    LastAttemptTime = log.Time,
                    Service = log.Service
                };
                _suspiciousList.Add(suspect);
            }
            else
            {
                suspect.FailCount++;
                suspect.LastAttemptTime = log.Time;
            }

            var moduleRule = _modules.FirstOrDefault(m => m.ModuleName == log.Service);
            int blockFor = (moduleRule != null) ? moduleRule.BlockLimit : _gateConfig.AutoBlockLimit;
            int alertFor = (moduleRule != null) ? moduleRule.AlertLimit : 5;

            if (suspect.FailCount == alertFor)
            {
                var pConfig = ConfigManager.LoadProtectionConfig(); 
                 _ = AlertManager.SendAlertAsync(pConfig, $"UYARI: {log.Service} Saldırısı", 
                     $"IP: {log.AttackerIp}\nÜlke: {log.AttackerCountry}\nSayaç: {suspect.FailCount}");
            }

            if (suspect.FailCount >= blockFor)
            {
                BlockUser(suspect.IpAddress, suspect.Country, $"{log.Service} Limit Aşımı");
                
                if (_protectionConfig.AlertOnBlock)
                {
                    _ = AlertManager.SendAlertAsync(_protectionConfig,
                        "Simsek - IP Engellendi",
                        $"IP: {suspect.IpAddress}\nÜlke: {suspect.Country}\nServis: {log.Service}\nLimit: {blockFor}\nDurum: Kalıcı olarak engellendi.");
                }
                _suspiciousList.Remove(suspect);
            }
            else if (suspect.FailCount == alertFor)
            {
                bool isCritical = (log.Service.Contains("MSSQL") || log.Service.Contains("RDP"));
                if (_protectionConfig.AlertOnCriticalModule && isCritical)
                {
                    _ = AlertManager.SendAlertAsync(_protectionConfig,
                        "Simsek - Şüpheli Aktivite Uyarısı",
                        $"Kritik bir serviste ({log.Service}) şüpheli aktivite!\nIP: {suspect.IpAddress}\nÜlke: {suspect.Country}\nDeneme Sayısı: {suspect.FailCount}\nKullanıcı: {log.TargetUsername}");
                }
            }
        }

        public void BlockUser(string ip, string country, string reason)
        {
            if (_gateConfig.IpWhitelist.Contains(ip))
            {
                OnStatusChanged?.Invoke($"BLOK İPTAL: {ip} Whitelist'te mevcut!");
                return;
            }

             if (_gateConfig.IpBlacklist.Any(x => x.Ip == ip)) return;

            var newItem = new BannedItem { Ip = ip, Country = country, BanDate = DateTime.Now, Reason = reason };
            _gateConfig.IpBlacklist.Add(newItem);
            
            ConfigManager.Save(_gateConfig);
            FirewallHelper.SyncBlacklist(_gateConfig.IpBlacklist);
            
            DatabaseManager.InsertBannedIp(ip, country, reason);

            OnStatusChanged?.Invoke($"ENGEL: {ip} ({reason})");
        }

        public void ManualBlock(string ip)
        {
            BlockUser(ip, "Bilinmiyor", "Yönetici Engeli");
        }
    }
}
