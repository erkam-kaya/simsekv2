﻿using H.Pipes;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Simsek.Core;
using System.Diagnostics.Eventing.Reader;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Xml;
using System.IO;
using System.Linq;
using System.Data.SQLite;
using System.Text.RegularExpressions;

namespace Simsek.Service
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private PipeServer<SimsekMessage>? _server;

        // Dinleyicileri (Ajanları) hafızada tutmak için listeler
        private List<EventLogWatcher> _eventWatchers = new List<EventLogWatcher>();
        private List<FileSystemWatcher> _fileWatchers = new List<FileSystemWatcher>();

        // Debounce Tracking
        private static readonly Dictionary<string, long> _lastProcessedEventIds = new Dictionary<string, long>();
        private static readonly Dictionary<string, (string Content, DateTime Time)> _lastProcessedFileLines = new Dictionary<string, (string, DateTime)>();
        private static readonly object _lockObj = new object();

        private static readonly HttpClient _httpClient = new HttpClient();
        private string _myMachineName = Environment.MachineName;
        private string _myMachineIp = "127.0.0.1";

        private readonly ProtectionService _protectionService;

        public Worker(ILogger<Worker> logger, ProtectionService protectionService)
        {
            _logger = logger;
            _protectionService = protectionService;
            _httpClient.Timeout = TimeSpan.FromSeconds(2);
            _myMachineIp = GetLocalIPAddress();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // 1. Veritabanını kontrol et
            DatabaseManager.Initialize();
            DatabaseManager.CleanupOldLogs();

            // 2. Protection Servisi Başlat (Olayları Bağla)
            _protectionService.OnAttackDetected += async (log) => 
            {
                if (_server != null)
                {
                    try
                    {
                        await _server.WriteAsync(new SimsekMessage { Text = "SALDIRI_VAR", Logs = new List<AttackLog> { log } });
                    }
                    catch { /* Ignore pipe errors */ }
                }
            };
            
            _protectionService.OnStatusChanged += async (msg) => 
            {
                try
                {
                    _logger.LogInformation($"STATUS: {msg}");
                    await SendStatus(msg);
                }
                catch (Exception ex) { _logger.LogError($"OnStatusChanged Error: {ex.Message}"); }
            };

            // 3. UI ile haberleşme hattını aç
            _server = new PipeServer<SimsekMessage>("SimsekPipe");

            _server.ClientConnected += async (o, args) =>
            {
                try
                {
                    await SendStatus("Servis Bağlandı. Koruma Aktif.");
                }
                catch (Exception ex) { _logger.LogError($"ClientConnected Error: {ex.Message}"); }
            };

            _server.MessageReceived += (o, args) =>
            {
                if (args.Message.Text == "REFRESH_MODULES" || args.Message.Text == "REFRESH_RULES")
                {
                    _protectionService.ReloadConfig();
                    LoadWatchers(); // Restart watchers when modules change
                }
                else if (args.Message.Text == "BLOCK_COMMAND")
                {
                   // UI'dan gelen manuel ban isteği: Data içinde IP var varsayıyoruz
                   if (!string.IsNullOrEmpty(args.Message.Data))
                   {
                       _protectionService.ManualBlock(args.Message.Data);
                   }
                }
            };

            try
            {
                await _server.StartAsync(cancellationToken: stoppingToken);
                _logger.LogInformation("Pipe Server Started Successfully.");
            }
            catch (IOException ex)
            {
                _logger.LogWarning($"Pipe Server Start Failed (Likely another instance running): {ex.Message}");
                // We continue, ensuring the service doesn't crash.
            }
            catch (Exception ex)
            {
                _logger.LogError($"Pipe Server Critical Error: {ex.Message}");
            }

            // İlk açılışta modülleri yükle (ProtectionService zaten ctor'da yaptı ama tazeleyelim)
            _protectionService.ReloadConfig();
            
            // Log İzleyicilerini Başlat
            LoadWatchers();

            // Servis kapanana kadar bekle
            int tickCounter = 0;
            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(1000, stoppingToken);
                
                // Her saat başı (3600 saniye) kontrol et
                tickCounter++;
                if (tickCounter >= 3600)
                {
                    tickCounter = 0;
                    await CheckScheduledTasks();
                }
            }

            StopAllWatchers();
            await _server.DisposeAsync();
        }
        private void StopAllWatchers()
        {
            // Properly dispose event watchers and detach handlers
            foreach (var w in _eventWatchers) 
            { 
                try 
                { 
                    w.Enabled = false;
                    w.EventRecordWritten -= null; // Detach all handlers
                    w.Dispose(); 
                } 
                catch { } 
            }
            _eventWatchers.Clear();

            // Properly dispose file watchers and detach handlers
            foreach (var w in _fileWatchers) 
            { 
                try 
                { 
                    w.EnableRaisingEvents = false;
                    w.Changed -= null; // Detach all handlers
                    w.Dispose(); 
                } 
                catch { } 
            }
            _fileWatchers.Clear();
        }

        // --- İZLEYİCİLERİ YÜKLE ---
        private void LoadWatchers()
        {
            StopAllWatchers(); // Önce temizlik
            int count = 0;

            try
            {
                using (var conn = DatabaseManager.GetConnection())
                {
                    conn.Open();
                    string sql = "SELECT * FROM Modules WHERE IsActive = 1";
                    using (var cmd = new SQLiteCommand(sql, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string name = reader["ModuleName"].ToString();
                            string type = reader["LogType"].ToString();
                            string source = reader["LogSource"].ToString();
                            string pattern = reader["DetectionPattern"].ToString();

                            if (type == "EventLog")
                            {
                                SetupEventWatcher(name, source, pattern);
                            }
                            else if (type == "FileLog")
                            {
                                SetupFileWatcher(name, source, pattern);
                            }
                            count++;
                        }
                    }
                }
                _logger.LogInformation($"{count} modül izlemeye alındı.");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Modül Yükleme Hatası: {ex.Message}");
            }
        }

        // --- TİP 1: WINDOWS EVENT LOG AJANI ---
        private void SetupEventWatcher(string moduleName, string logName, string pattern)
        {
            try
            {
                string queryStr = pattern;
                // Eğer pattern basit bir "EventID=123" formatındaysa, onu XPath'e çevir.
                // Değilse (örn: *[...] veya <QueryList>...), olduğu gibi kullan.
                if (!pattern.StartsWith("*") && !pattern.StartsWith("<"))
                {
                   if (pattern.Contains("EventID="))
                   {
                       string id = pattern.Split('=')[1];
                       queryStr = $"*[System[(EventID={id})]]";
                   }
                   else
                   {
                       // Varsayılan: Sadece EventID numarası girilmişse
                       queryStr = $"*[System[(EventID={pattern})]]";
                   }
                }

                var query = new EventLogQuery(logName, PathType.LogName, queryStr);
                var watcher = new EventLogWatcher(query);

                watcher.EventRecordWritten += (s, e) => ProcessEventLog(e, moduleName);

                watcher.Enabled = true;
                _eventWatchers.Add(watcher);
            }
            catch { }
        }

        // --- TİP 2: DOSYA LOG AJANI ---
        private void SetupFileWatcher(string moduleName, string path, string pattern)
        {
            try
            {
                string dir = path;
                string filter = "*.log";

                // Eğer path bir dosya ise (uzantısı varsa veya File.Exists ise)
                if (File.Exists(path) || Path.HasExtension(path))
                {
                    dir = Path.GetDirectoryName(path) ?? path;
                    filter = Path.GetFileName(path);
                }

                if (!Directory.Exists(dir)) return;

                var watcher = new FileSystemWatcher(dir, filter);
                watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size | NotifyFilters.FileName;
                watcher.IncludeSubdirectories = false; // Dosya izliyorsak alt klasör gerekmez

                watcher.Changed += (s, e) => ProcessFileLog(e, moduleName, pattern);

                watcher.EnableRaisingEvents = true;
                _fileWatchers.Add(watcher);
                 _logger.LogInformation($"Dosya İzleniyor: {dir}\\{filter}");
            }
            catch (Exception ex) { _logger.LogError($"WATCHER SETUP ERROR: {ex.Message}"); }
        }

        private async void ProcessEventLog(EventRecordWrittenEventArgs e, string moduleName)
        {
            if (e.EventRecord == null) return;
            try
            {
                // DEBOUNCE LOGIC FOR EVENT LOGS
                long recordId = e.EventRecord.RecordId ?? 0;
                if (recordId > 0)
                {
                    lock (_lockObj)
                    {
                        if (_lastProcessedEventIds.ContainsKey(moduleName) && _lastProcessedEventIds[moduleName] == recordId)
                        {
                            return; // Already processed this event
                        }
                        _lastProcessedEventIds[moduleName] = recordId;
                    }
                }

                string originalDescription = e.EventRecord.FormatDescription();
                if (string.IsNullOrEmpty(originalDescription)) originalDescription = e.EventRecord.ToXml();

                string xml = e.EventRecord.ToXml();
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xml);
                XmlNamespaceManager ns = new XmlNamespaceManager(doc.NameTable);
                ns.AddNamespace("ns", "http://schemas.microsoft.com/win/2004/08/events/event");

                string ip = ExtractData(doc, ns, "IpAddress") ?? ExtractData(doc, ns, "ClientIP");
                string user = ExtractData(doc, ns, "TargetUserName") ?? ExtractData(doc, ns, "AccountName");
                
                // IP Regex Fallback
                if (string.IsNullOrEmpty(ip) || ip.Length < 3 || ip == "-")
                {
                    var matchIp = Regex.Match(originalDescription, @"Source Network Address:\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})");
                    if (matchIp.Success) ip = matchIp.Groups[1].Value;
                }

                if (string.IsNullOrEmpty(ip) || ip == "-" || ip.StartsWith("127.") || ip == "::1") return;

                string country = await GetCountryFromIp(ip);

                var log = new AttackLog
                {
                    Time = DateTime.Now,
                    MachineName = _myMachineName,
                    MachineIp = _myMachineIp,
                    Service = moduleName,
                    EventType = $"EventID: {e.EventRecord.Id}",
                    AttackerIp = ip,
                    AttackerCountry = country,
                    TargetUsername = user ?? "Bilinmiyor",
                    FullMessage = originalDescription
                };

                // ANALİZ VE ENGELLEME İÇİN PROTECTION SERVICE'A GÖNDER
                await _protectionService.AnalyzeLog(log);
            }
            catch { }
        }

        private async void ProcessFileLog(FileSystemEventArgs e, string moduleName, string patternRegex)
        {
            try
            {
                await Task.Delay(100); // Short delay to let file write finish

                using (var fs = new FileStream(e.FullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sr = new StreamReader(fs))
                {
                    if (sr.BaseStream.Length > 1000) sr.BaseStream.Seek(-1000, SeekOrigin.End);
                    string content = await sr.ReadToEndAsync();
                    string line = content.Split(Environment.NewLine).LastOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "";

                    if (string.IsNullOrEmpty(line)) return;

                    // DEBOUNCE LOGIC FOR FILES
                    lock (_lockObj)
                    {
                        if (_lastProcessedFileLines.TryGetValue(moduleName, out var lastEntry))
                        {
                            // If same content and within 1 second, skip
                            if (lastEntry.Content == line && (DateTime.Now - lastEntry.Time).TotalSeconds < 1)
                            {
                                return;
                            }
                        }
                        _lastProcessedFileLines[moduleName] = (line, DateTime.Now);
                    }

                    if (Regex.IsMatch(line, patternRegex, RegexOptions.IgnoreCase))
                    {
                        string ipPattern = @"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b";
                        var match = Regex.Match(line, ipPattern);
                        string ip = match.Success ? match.Value : "Bilinmiyor";
                        string country = "??";

                        if (ip != "Bilinmiyor" && !ip.StartsWith("192.") && !ip.StartsWith("127."))
                            country = await GetCountryFromIp(ip);

                        var log = new AttackLog
                        {
                            Time = DateTime.Now,
                            MachineName = _myMachineName,
                            MachineIp = _myMachineIp,
                            Service = moduleName,
                            EventType = "Erişim Hatası",
                            AttackerIp = ip,
                            AttackerCountry = country,
                            TargetUsername = "System",
                            FullMessage = line
                        };

                        // ANALİZ İÇİN SERVİSE GÖNDER
                        await _protectionService.AnalyzeLog(log);
                    }
                }
            }
            catch (Exception ex) 
            { 
                 _logger.LogError($"FILE PROCESS ERROR: {ex.Message}");
            }
        }

        private async Task SendStatus(string msg)
        {
            if (_server != null)
            {
                try { await _server.WriteAsync(new SimsekMessage { Text = "DURUM", Data = msg }); }
                catch { /* Ignore pipe write errors */ }
            }
        }

        // SendAttack metodu kaldırıldı, artık ProtectionService üzerinden gidiyor ve olay tabanlı çalışıyor.


        private async Task<string> GetCountryFromIp(string ip)
        {
            try
            {
                if (ip.StartsWith("192.") || ip.StartsWith("127.") || ip.StartsWith("10.")) return "Yerel";
                string json = await _httpClient.GetStringAsync($"http://ip-api.com/json/{ip}?fields=countryCode");
                using JsonDocument doc = JsonDocument.Parse(json);
                return doc.RootElement.GetProperty("countryCode").GetString() ?? "??";
            }
            catch { return "??"; }
        }

        private string? ExtractData(XmlDocument doc, XmlNamespaceManager ns, string field) => doc.SelectSingleNode($"//ns:Data[@Name='{field}']", ns)?.InnerText;

        private string GetLocalIPAddress()
        {
            try { return Dns.GetHostEntry(Dns.GetHostName()).AddressList.FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork)?.ToString() ?? "127.0.0.1"; } catch { return "127.0.0.1"; }
        }

        private async Task CheckScheduledTasks()
        {
            try
            {
                var config = ConfigManager.LoadProtectionConfig();
                bool configChanged = false;

                // 1. Log Raporu Kontrolü
                if (config.ReportFrequency != "Never")
                {
                    int daysSince = (DateTime.Now - config.LastReportDate).Days;
                    bool due = false;
                    int reportDays = 1;

                    if (config.ReportFrequency == "Weekly" && daysSince >= 7) { due = true; reportDays = 7; }
                    else if (config.ReportFrequency == "Monthly" && daysSince >= 30) { due = true; reportDays = 30; }

                    if (due)
                    {
                        try
                        {
                            string path = ReportManager.GenerateSummaryReport(reportDays);
                            await AlertManager.SendAlertAsync(config, $"Simsek Security - Otomatik {config.ReportFrequency} Rapor", "Simsek Security tarafından oluşturulan otomatik rapor ektedir.", path);
                            config.LastReportDate = DateTime.Now;
                            configChanged = true;
                            _logger.LogInformation($"Otomatik Rapor ({config.ReportFrequency}) gönderildi.");
                        }
                        catch (Exception ex) { _logger.LogError($"Otomatik Rapor Hatası: {ex.Message}"); }
                    }
                }

                // 2. DB Bakım Kontrolü
                if (config.DbMaintenanceFrequency != "Never")
                {
                    int daysSince = (DateTime.Now - config.LastMaintenanceDate).Days;
                    bool due = false;
                    int keepDays = 30; // Default
                    if (config.DbMaintenanceFrequency == "Weekly" && daysSince >= 7) { due = true; keepDays = 7; }
                    else if (config.DbMaintenanceFrequency == "Monthly" && daysSince >= 30) { due = true; keepDays = 30; }

                    if (due)
                    {
                        try
                        {
                            DatabaseManager.CleanupOldLogs(keepDays);
                            config.LastMaintenanceDate = DateTime.Now;
                            configChanged = true;
                            _logger.LogInformation($"Veritabanı bakımı yapıldı ({config.DbMaintenanceFrequency}). Eski loglar temizlendi.");
                        }
                        catch (Exception ex) { _logger.LogError($"DB Bakım Hatası: {ex.Message}"); }
                    }
                }

                if (configChanged) ConfigManager.SaveProtectionConfig(config);
            }
            catch (Exception ex)
            {
                _logger.LogError($"CheckScheduledTasks Error: {ex.Message}");
            }
        }
    }
}