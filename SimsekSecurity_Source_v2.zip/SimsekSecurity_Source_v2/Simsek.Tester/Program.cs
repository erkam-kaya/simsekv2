﻿using System;
using System.Collections.Generic;
using Simsek.Core;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("=== Simsek Database Manager ===\n");
        
        if (args.Length > 0 && args[0] == "clean")
        {
            CleanDatabase();
        }
        else if (args.Length > 0 && args[0] == "sample")
        {
            AddSampleData();
        }
        else
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  dotnet run clean   - Clean all logs");
            Console.WriteLine("  dotnet run sample  - Add sample data");
        }
    }
    
    static void CleanDatabase()
    {
        Console.WriteLine("Cleaning database...");
        try
        {
            using (var conn = DatabaseManager.GetConnection())
            {
                conn.Open();
                
                var cmd = new System.Data.SQLite.SQLiteCommand("SELECT COUNT(*) FROM AttackLogs", conn);
                long before = (long)cmd.ExecuteScalar();
                Console.WriteLine($"Logs before: {before}");
                
                cmd = new System.Data.SQLite.SQLiteCommand("DELETE FROM AttackLogs", conn);
                int deleted = cmd.ExecuteNonQuery();
                Console.WriteLine($"Deleted: {deleted} logs");
                
                cmd = new System.Data.SQLite.SQLiteCommand("DELETE FROM sqlite_sequence WHERE name='AttackLogs'", conn);
                cmd.ExecuteNonQuery();
                Console.WriteLine("Reset ID counter");
                
                Console.WriteLine("\nCleanup complete!");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ERROR: {ex.Message}");
        }
    }
    
    static void AddSampleData()
    {
        Console.WriteLine("Adding sample attack logs...\n");
        
        var samples = new List<AttackLog>
        {
            new AttackLog { Time = DateTime.Parse("2026-02-08 15:30:00"), AttackerIp = "192.168.1.100", AttackerCountry = "TR", Service = "RDP", FullMessage = "Failed RDP login attempt", TargetUsername = "administrator", EventType = "Brute Force", IsBlocked = true },
            new AttackLog { Time = DateTime.Parse("2026-02-08 15:31:15"), AttackerIp = "45.142.212.61", AttackerCountry = "RU", Service = "MSSQL", FullMessage = "SQL authentication failure", TargetUsername = "sa", EventType = "SQL Injection Attempt", IsBlocked = true },
            new AttackLog { Time = DateTime.Parse("2026-02-08 15:32:30"), AttackerIp = "103.75.32.18", AttackerCountry = "CN", Service = "RDP", FullMessage = "Multiple failed login attempts", TargetUsername = "admin", EventType = "Brute Force", IsBlocked = true },
            new AttackLog { Time = DateTime.Parse("2026-02-08 15:33:45"), AttackerIp = "185.220.101.42", AttackerCountry = "DE", Service = "FTP", FullMessage = "FTP brute force detected", TargetUsername = "ftpuser", EventType = "FTP Attack", IsBlocked = false },
            new AttackLog { Time = DateTime.Parse("2026-02-08 15:35:00"), AttackerIp = "198.51.100.23", AttackerCountry = "US", Service = "SSH", FullMessage = "SSH authentication failure", TargetUsername = "root", EventType = "SSH Brute Force", IsBlocked = true }
        };
        
        foreach (var log in samples)
        {
            DatabaseManager.InsertAttackLog(log, log.IsBlocked);
            Console.WriteLine($"  + Added {log.Service} attack from {log.AttackerCountry}");
        }
        
        try
        {
            using (var conn = DatabaseManager.GetConnection())
            {
                conn.Open();
                var cmd = new System.Data.SQLite.SQLiteCommand("SELECT COUNT(*) FROM AttackLogs", conn);
                long total = (long)cmd.ExecuteScalar();
                Console.WriteLine($"\nTotal logs in database: {total}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ERROR: {ex.Message}");
        }
        
        Console.WriteLine("Sample data added successfully!");
    }
}
