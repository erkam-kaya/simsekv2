﻿using H.Pipes;
using Simsek.Core;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using System.Net;
using System.Collections.Generic;
using System;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using Microsoft.Win32;
using System.IO;
using System.Data.SQLite;
using System.Threading.Tasks;
using System.Diagnostics;
using System.ComponentModel;
using LiveCharts;
using LiveCharts.Wpf;
using MaterialDesignThemes.Wpf;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Simsek.UI
{
    // ARAYÜZ İÇİN YARDIMCI SINIFLAR
    public class UlkeBilgisi { public string Name { get; set; } public int Count { get; set; } }

    public class ModuleConfigItem
    {
        public int Id { get; set; }
        public string ModuleName { get; set; }
        public string LogSource { get; set; }
        public int BlockLimit { get; set; }
        public int AlertLimit { get; set; }
        public int IsActive { get; set; }
        public bool IsActiveBool { get => IsActive == 1; set => IsActive = value ? 1 : 0; }
    }

    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        private PipeClient<SimsekMessage>? _client;

        // --- VERİ KOLEKSİYONLARI ---
        public ObservableCollection<AttackLog> LiveTrafficList { get; set; } = new ObservableCollection<AttackLog>();
        public ObservableCollection<AttackLog> AllLogsList { get; set; } = new ObservableCollection<AttackLog>(); // NEW: Full Log List
        public SeriesCollection ChartSeries { get; set; }

        public ObservableCollection<ModuleConfigItem> ModulesList { get; set; } = new ObservableCollection<ModuleConfigItem>();
        public ObservableCollection<UlkeBilgisi> TopCountryList { get; set; } = new ObservableCollection<UlkeBilgisi>();

        private GateConfig _gateConfig;
        private ObservableCollection<string> _visibleGeoList;
        private ObservableCollection<SuspiciousIp> _suspiciousList = new ObservableCollection<SuspiciousIp>();
        
        private DispatcherTimer _dashboardTimer;

        // LİSTE VE AYAR DEĞİŞKENLERİ
        private ObservableCollection<BannedItem> _currentEditingBlacklist;
        // DÜZELTME 1: Whitelist de artık BannedItem listesi olarak tutuluyor (Grid görebilsin diye)
        private ObservableCollection<BannedItem> _currentEditingWhitelist;
        private bool _isEditingBlacklist = false;
        private ModuleConfigItem _currentEditingModule;
        private bool _logsLoaded = false; // Track if logs have been loaded

        public MainWindow()
        {
            ChartSeries = new SeriesCollection();
            try
            {
                InitializeComponent();
                DataContext = this;
                System.Diagnostics.Debug.WriteLine("MainWindow: InitializeComponent completed");

                // 1. Veritabanını Kontrol Et
                try
                {
                    DatabaseManager.Initialize();
                    System.Diagnostics.Debug.WriteLine("MainWindow: Database initialized");
                }
                catch (Exception dbEx)
                {
                    System.Diagnostics.Debug.WriteLine($"MainWindow: Database init error: {dbEx.Message}");
                    MessageBox.Show($"Veritabanı başlatma hatası:\n{dbEx.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

                // 2. Ayarları Yükle
                try
                {
                    LoadSettingsFromDb();
                    System.Diagnostics.Debug.WriteLine("MainWindow: Settings loaded");
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"MainWindow: Settings load error: {ex.Message}");
                }

                try
                {
                    LoadModulesFromDb();
                    System.Diagnostics.Debug.WriteLine("MainWindow: Modules loaded");
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"MainWindow: Modules load error: {ex.Message}");
                }

                // 2.5. Apply Language
                try
                {
                    ApplyLanguage();
                }
                catch (Exception ex) { System.Diagnostics.Debug.WriteLine("Lang Error: " + ex.Message); }

                // 3. UI Bağlamaları
                try
                {
                    if (GridLiveTraffic != null)
                        GridLiveTraffic.ItemsSource = LiveTrafficList;
                    
                    if (GridAllLogs != null)
                        GridAllLogs.ItemsSource = AllLogsList;
                    
                    System.Diagnostics.Debug.WriteLine("MainWindow: DataGrids bound");
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"MainWindow: DataGrid binding error: {ex.Message}");
                }

                DataContext = this;
                
                if (ListTopCountries != null)
                    ListTopCountries.ItemsSource = TopCountryList;

                try
                {
                    InitializeGateControl();
                    System.Diagnostics.Debug.WriteLine("MainWindow: Gate control initialized");
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"MainWindow: Gate control error: {ex.Message}");
                }

                // Bildirim Süresi (3 Saniye)
                try
                {
                    if (MainSnackbar != null)
                        MainSnackbar.MessageQueue = new MaterialDesignThemes.Wpf.SnackbarMessageQueue(TimeSpan.FromSeconds(3));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"MainWindow: Snackbar init error: {ex.Message}");
                }

                // Dashboard Timer (5 Saniye)
                try
                {
                    _dashboardTimer = new DispatcherTimer();
                    _dashboardTimer.Interval = TimeSpan.FromSeconds(5);
                    _dashboardTimer.Tick += (s, e) => RefreshDashboard();
                    _dashboardTimer.Start();
                    RefreshDashboard();
                    System.Diagnostics.Debug.WriteLine("MainWindow: Dashboard timer started");
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"MainWindow: Timer error: {ex.Message}");
                }

                this.Loaded += MainWindow_Loaded;
                this.Closing += MainWindow_Closing;
                
                System.Diagnostics.Debug.WriteLine("MainWindow: Constructor completed successfully");
            }
            catch (Exception ex)
            {
                File.WriteAllText("mainwindow_error.txt", $"MainWindow Constructor Error: {ex.Message}\n{ex.StackTrace}");
                MessageBox.Show($"Uygulama başlatma hatası:\n{ex.Message}\n\nDetaylar Debug çıktısında.", 
                    "Kritik Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown();
            }
        }

        private void LoadAllLogs()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("LoadAllLogs: Starting...");
                
                // Ensure we're on UI thread for collection operations
                if (!Dispatcher.CheckAccess())
                {
                    Dispatcher.Invoke(() => LoadAllLogs());
                    return;
                }
                
                if (AllLogsList == null)
                {
                    System.Diagnostics.Debug.WriteLine("LoadAllLogs: AllLogsList is null, initializing...");
                    AllLogsList = new ObservableCollection<AttackLog>();
                    if (GridAllLogs != null)
                    {
                        GridAllLogs.ItemsSource = AllLogsList;
                    }
                }
                
                AllLogsList.Clear();
                System.Diagnostics.Debug.WriteLine("LoadAllLogs: Cleared existing logs");
                
                // Load logs from database in background
                Task.Run(() =>
                {
                    var tempLogs = new List<AttackLog>();
                    int count = 0;
                    
                    try
                    {
                        using (var conn = DatabaseManager.GetConnection())
                        {
                            System.Diagnostics.Debug.WriteLine("LoadAllLogs: Got database connection");
                            conn.Open();
                            System.Diagnostics.Debug.WriteLine("LoadAllLogs: Database opened");
                            
                            // Load last 500 logs
                            var cmd = new SQLiteCommand("SELECT * FROM AttackLogs ORDER BY Timestamp DESC LIMIT 500", conn);
                            using (var reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    try
                                    {
                                        var log = new AttackLog
                                        {
                                            Time = reader["Timestamp"] != DBNull.Value 
                                                ? Convert.ToDateTime(reader["Timestamp"]) 
                                                : DateTime.Now,
                                            AttackerIp = reader["IpAddress"]?.ToString() ?? "Bilinmiyor",
                                            AttackerCountry = reader["Country"]?.ToString() ?? "??",
                                            Service = reader["Service"]?.ToString() ?? "Genel",
                                            FullMessage = reader["LogDetails"]?.ToString() ?? "",
                                            EventType = reader["Service"]?.ToString() ?? "Saldırı",
                                            Id = Convert.ToInt32(reader["Id"]),
                                            IsBlocked = reader["IsBlocked"] != DBNull.Value && Convert.ToInt32(reader["IsBlocked"]) == 1
                                        };

                                        try { log.TargetUsername = reader["TargetUsername"]?.ToString() ?? "-"; } 
                                        catch { log.TargetUsername = "-"; }
                                        
                                        // Fill in properties not in database with defaults
                                        log.MachineName = Environment.MachineName;  // Current server name
                                        log.MachineIp = "10.100.114.144";          // Local IP (can be updated later)
                                        log.EventId = 0;                            // Default event ID
                                        log.IsSuccess = false;                      // Assume failed attacks
                                        
                                        tempLogs.Add(log);
                                        count++;
                                    }
                                    catch (Exception rowEx)
                                    {
                                        System.Diagnostics.Debug.WriteLine($"LoadAllLogs: Error reading row: {rowEx.Message}");
                                    }
                                }
                                System.Diagnostics.Debug.WriteLine($"LoadAllLogs: Loaded {count} logs from database");
                            }
                        }
                    }
                    catch (Exception dbEx)
                    {
                        System.Diagnostics.Debug.WriteLine($"LoadAllLogs: Database error: {dbEx.Message}");
                    }
                    
                    // Update UI on UI thread
                    Dispatcher.Invoke(() =>
                    {
                        try
                        {
                            // If no logs, add a placeholder
                            if (tempLogs.Count == 0)
                            {
                                AllLogsList.Add(new AttackLog
                                {
                                    Time = DateTime.Now,
                                    AttackerIp = "Henüz log yok",
                                    AttackerCountry = "--",
                                    Service = "Sistem",
                                    FullMessage = "Henüz hiç saldırı kaydı bulunmuyor. Sistem aktif olduğunda loglar burada görünecek.",
                                    EventType = "Bilgi",
                                    TargetUsername = "-"
                                });
                            }
                            else
                            {
                                foreach (var log in tempLogs)
                                {
                                    AllLogsList.Add(log);
                                }
                            }
                            
                            System.Diagnostics.Debug.WriteLine($"LoadAllLogs: Added {AllLogsList.Count} logs to UI");
                        }
                        catch (Exception uiEx)
                        {
                            System.Diagnostics.Debug.WriteLine($"LoadAllLogs: UI update error: {uiEx.Message}");
                            MessageBox.Show($"Log görüntüleme hatası:\n{uiEx.Message}", 
                                "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    });
                });
                
                System.Diagnostics.Debug.WriteLine("LoadAllLogs: Background load started");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"LoadAllLogs CRITICAL ERROR: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"Stack Trace: {ex.StackTrace}");
                
                // Show error to user
                try
                {
                    MessageBox.Show($"Log yükleme hatası:\n{ex.Message}\n\nDetaylar Debug çıktısında.", 
                        "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch { }
            }
        }

        private void RefreshDashboard()
        {
            try
            {
                // 1. Get attack count from database
                int totalAttacks = DatabaseManager.GetAttackCount24Hours();
                if (TxtTotalCount != null) 
                    TxtTotalCount.Text = totalAttacks.ToString();
                
                // 2. Get top 5 countries
                var topCountries = DatabaseManager.GetTopCountries(5);
                TopCountryList.Clear();
                foreach (var country in topCountries)
                {
                    TopCountryList.Add(new UlkeBilgisi { Name = country.Name, Count = country.Count });
                }

                // 3. Get active modules
                var activeModules = DatabaseManager.GetActiveModuleNames();
                if (TxtActiveModules != null) 
                    TxtActiveModules.Text = activeModules.Count > 0 ? string.Join(", ", activeModules) : "PASİF";

                // Chart logic restored
                string chartType = "Country";
                if (ComboChartType != null && ComboChartType.SelectedItem is ComboBoxItem selectedItem && selectedItem.Tag != null)
                {
                    chartType = selectedItem.Tag.ToString();
                }

                string groupByColumn = chartType == "Service" ? "Service" : "Country";
                
                var chartData = new List<UlkeBilgisi>();
                
                using (var conn = DatabaseManager.GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand($"SELECT {groupByColumn}, COUNT(*) as Count FROM AttackLogs GROUP BY {groupByColumn} ORDER BY Count DESC LIMIT 5", conn);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            chartData.Add(new UlkeBilgisi
                            {
                                Name = reader[groupByColumn].ToString(),
                                Count = Convert.ToInt32(reader["Count"])
                            });
                        }
                    }
                }

                ChartSeries.Clear();
                foreach (var item in chartData)
                {
                    ChartSeries.Add(new PieSeries
                    {
                        Title = item.Name,
                        Values = new ChartValues<int> { item.Count },
                        DataLabels = true,
                        LabelPoint = point => $"{point.Y} ({point.Participation:P0})"
                    });
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"RefreshDashboard Error: {ex.Message}");
                MessageBox.Show($"Dashboard yenileme hatası: {ex.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ComboChartType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshDashboard();
        }

        private async void LoadHostInfo()
        {
            try
            {
                 // Immediate test - set default values to verify UI elements exist
                 Dispatcher.Invoke(() => 
                 {
                     if (TxtHostLan != null) TxtHostLan.Text = "LAN: Yükleniyor...";
                     if (TxtHostWan != null) TxtHostWan.Text = "WAN: Yükleniyor...";
                     if (TxtHostGeo != null) TxtHostGeo.Text = "Konum: Yükleniyor...";
                     else System.Diagnostics.Debug.WriteLine("WARNING: TxtHostGeo is NULL!");
                 });

                 string lanIp = "127.0.0.1";
                 try {
                     using (System.Net.Sockets.Socket socket = new System.Net.Sockets.Socket(System.Net.Sockets.AddressFamily.InterNetwork, System.Net.Sockets.SocketType.Dgram, 0))
                     {
                        socket.Connect("8.8.8.8", 65530);
                        IPEndPoint? endPoint = socket.LocalEndPoint as IPEndPoint;
                        if (endPoint != null) lanIp = endPoint.Address.ToString();
                     }
                 } catch (Exception ex) {
                     System.Diagnostics.Debug.WriteLine($"LAN IP Error: {ex.Message}");
                 }

                 string wanIp = "-";
                 string country = "-";

                 await Task.Run(async () => 
                 {
                     try 
                     {
                         using (var client = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromSeconds(5) })
                         {
                             // Try primary API
                             try
                             {
                                 string json = await client.GetStringAsync("http://ip-api.com/json/?fields=query,countryCode");
                                 using (var doc = System.Text.Json.JsonDocument.Parse(json))
                                 {
                                     wanIp = doc.RootElement.GetProperty("query").GetString() ?? "-";
                                     country = doc.RootElement.GetProperty("countryCode").GetString() ?? "-";
                                 }
                                 System.Diagnostics.Debug.WriteLine($"WAN IP loaded: {wanIp}, Country: {country}");
                             }
                             catch (Exception ex1)
                             {
                                 System.Diagnostics.Debug.WriteLine($"Primary API failed: {ex1.Message}");
                                 
                                 // Fallback to secondary API
                                 try
                                 {
                                     string ip = await client.GetStringAsync("https://api.ipify.org");
                                     wanIp = ip.Trim();
                                     country = "N/A";
                                     System.Diagnostics.Debug.WriteLine($"Fallback WAN IP: {wanIp}");
                                 }
                                 catch (Exception ex2)
                                 {
                                     System.Diagnostics.Debug.WriteLine($"Fallback API also failed: {ex2.Message}");
                                 }
                             }
                         }
                     }
                     catch (Exception ex)
                     {
                         System.Diagnostics.Debug.WriteLine($"WAN IP Error: {ex.Message}");
                     }
                 });

                 // Update UI
                 Dispatcher.Invoke(() => 
                 {
                     if (TxtHostLan != null) TxtHostLan.Text = $"LAN: {lanIp}";
                     if (TxtHostWan != null) TxtHostWan.Text = $"WAN: {wanIp}";
                     if (TxtHostGeo != null) TxtHostGeo.Text = $"Konum: {country}";
                     
                     System.Diagnostics.Debug.WriteLine($"Host Info Updated - LAN: {lanIp}, WAN: {wanIp}, Country: {country}");
                 });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"LoadHostInfo Error: {ex.Message}");
            }
        }

        // --- CHART VE TOP LIST GÜNCELLEME (ESKİ METOTLAR - REFRESH DASHBOARD İÇİNE ALINDI) ---
        // private void UpdateChart() { ... } 
        // private void UpdateTop5() { ... }


        // --- LOG YAKALAMA VE İŞLEME ---
        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            _client = new PipeClient<SimsekMessage>("SimsekPipe");
            _client.MessageReceived += (o, args) =>
            {
                Dispatcher.Invoke(() =>
                {
                    if (args.Message.Text == "SALDIRI_VAR")
                    {
                        foreach (var log in args.Message.Logs)
                        {
                           ProcessLogForView(log);
                        }
                    }
                });
            };

            try { await _client.ConnectAsync(); await _client.WriteAsync(new SimsekMessage { Text = "UI_READY" }); }
            catch { DurumText.Text = "SERVİS YOK!"; DurumText.Foreground = System.Windows.Media.Brushes.Red; }

            // Initial Dashboard Load
            RefreshDashboard();

            // Load Host Info (with delay to ensure UI is ready)
            await Task.Delay(500);
            LoadHostInfo();

            // Load Recent Attacks for "Recent Attacks" Datagrid
             var recentLogs = await Task.Run(() => DatabaseManager.GetRecentAttackLogs(50));
             foreach (var log in recentLogs) LiveTrafficList.Add(log);

             // Load Profile Photo (Safe)
             LoadProfilePhoto();
        }

        // --- LOG İŞLEME VE GÖRSELLEŞTİRME ---
        private void ProcessLogForView(AttackLog log)
        {
            // Bu metot artık sadece GÖRSEL amaçlıdır. Engelleme serviste yapılır.
            
            // Grid'e Ekle
            LiveTrafficList.Insert(0, log);
            if (LiveTrafficList.Count > 100) LiveTrafficList.RemoveAt(100);
            
            // NEW: All Logs Listesine de Ekle
            AllLogsList.Insert(0, log);
            if (AllLogsList.Count > 1000) AllLogsList.RemoveAt(1000);

            if (TxtTotalCount != null) TxtTotalCount.Text = (int.Parse(TxtTotalCount.Text) + 1).ToString();

            // Şüpheli Listesini UI'da Güncelle (Görsel)
             if (log.EventType.Contains("Fail") || log.EventType.Contains("Hata") || log.EventType.Contains("403"))
            {
                var suspect = _suspiciousList.FirstOrDefault(x => x.IpAddress == log.AttackerIp);
                if (suspect == null)
                {
                    _suspiciousList.Insert(0, new SuspiciousIp
                    {
                        IpAddress = log.AttackerIp,
                        FailCount = 1,
                        Country = log.AttackerCountry,
                        LastAttemptTime = log.Time,
                        Service = log.Service
                    });
                }
                else
                {
                    suspect.FailCount++;
                    suspect.LastAttemptTime = log.Time;
                    // Sayacı güncellemek için listeden çıkarıp ekle (ObservableCollection tetiklensin)
                    _suspiciousList.Remove(suspect);
                    _suspiciousList.Insert(0, suspect);
                }
            }
        }

        private async void BlockUser(string ip, string country, string reason)
        {
            // ARTIK DOĞRUDAN ENGELLEMİYORUZ. SERVİSE KOMUT ATIYORUZ.
            if (_client != null && _client.IsConnected)
            {
                await _client.WriteAsync(new SimsekMessage { Text = "BLOCK_COMMAND", Data = ip });
                MainSnackbar.MessageQueue?.Enqueue($"{ip} İÇİN ENGELLEME İSTEĞİ GÖNDERİLDİ.");
            }
            else
            {
                MessageBox.Show("Servis bağlı değil! Engelleme yapılamadı.");
            }
        }

        // --- MODÜL AYARLARI ---
        private void BtnModuleSettings_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as System.Windows.Controls.Button;
            
            if (button?.Tag is ModuleConfigItem mod)
            {
                _currentEditingModule = mod;
                TxtSelectedModule.Text = mod.ModuleName;
                
                // Safe Set
                try { SliderBlock.Value = mod.BlockLimit; } catch { }
                try { SliderAlert.Value = mod.AlertLimit; } catch { }
                
                if (TxtBlockVal != null) TxtBlockVal.Text = mod.BlockLimit.ToString();
                if (TxtAlertVal != null) TxtAlertVal.Text = mod.AlertLimit.ToString();

                OverlayModuleSettings.Visibility = Visibility.Visible;
                MessageBox.Show($"Ayarlar açılıyor: {mod.ModuleName}", "Debug", MessageBoxButton.OK, MessageBoxImage.Information); 
            }
            else
            {
                MessageBox.Show("Hata: Modül verisi okunamadı (Tag null)", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void SliderBlock_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) { if (TxtBlockVal != null) TxtBlockVal.Text = ((int)e.NewValue).ToString(); }
        private void SliderAlert_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) { if (TxtAlertVal != null) TxtAlertVal.Text = ((int)e.NewValue).ToString(); }

        private void BtnCloseModuleSettings_Click(object sender, RoutedEventArgs e)
        {
            if (_currentEditingModule != null)
            {
                _currentEditingModule.BlockLimit = (int)SliderBlock.Value;
                _currentEditingModule.AlertLimit = (int)SliderAlert.Value;

                try
                {
                    using (var conn = DatabaseManager.GetConnection())
                    {
                        conn.Open();
                        string sql = "UPDATE Modules SET BlockLimit=@blim, AlertLimit=@alim WHERE Id=@id";
                        using (var cmd = new SQLiteCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@blim", _currentEditingModule.BlockLimit);
                            cmd.Parameters.AddWithValue("@alim", _currentEditingModule.AlertLimit);
                            cmd.Parameters.AddWithValue("@id", _currentEditingModule.Id);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    MainSnackbar.MessageQueue?.Enqueue($"{_currentEditingModule.ModuleName} ayarları güncellendi!");
                }
                catch (Exception ex) { MessageBox.Show("Kayıt Hatası: " + ex.Message); }
            }
            OverlayModuleSettings.Visibility = Visibility.Collapsed;
        }

        private void LoadSettingsFromDb() { _gateConfig = Simsek.Core.ConfigManager.Load(); }
        private void LoadModulesFromDb()
        {
            ModulesList.Clear();
            string activeNames = "";
            try
            {
                using (var conn = DatabaseManager.GetConnection())
                {
                    conn.Open();
                    var cmd = new SQLiteCommand("SELECT * FROM Modules", conn);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var m = new ModuleConfigItem
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                ModuleName = reader["ModuleName"].ToString(),
                                LogSource = reader["LogSource"].ToString(),
                                BlockLimit = Convert.ToInt32(reader["BlockLimit"]),
                                AlertLimit = Convert.ToInt32(reader["AlertLimit"]),
                                IsActive = Convert.ToInt32(reader["IsActive"])
                            };
                            ModulesList.Add(m);
                            if (m.IsActiveBool) activeNames += m.ModuleName + " ";
                        }
                    }
                }
                if (PanelModules != null)
                {
                    PanelModules.Children.Clear();
                    foreach (var mod in ModulesList)
                    {
                        var border = new Border
                        {
                            Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2D2D2D")), // Card Color
                            Width = 280,
                            Margin = new Thickness(10),
                            Padding = new Thickness(15),
                            CornerRadius = new CornerRadius(8)
                        };

                        var grid = new Grid();
                        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                        // Icon
                        var icon = new MaterialDesignThemes.Wpf.PackIcon { Width = 35, Height = 35, Foreground = Brushes.Gold, VerticalAlignment = VerticalAlignment.Center };
                        // Dynamic Icon Logic
                        if (mod.ModuleName.Contains("RDP")) icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.RemoteDesktop;
                        else if (mod.ModuleName.Contains("MSSQL")) icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.Database;
                        else if (mod.ModuleName.Contains("IIS")) icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.Web;
                        else if (mod.ModuleName.Contains("VPN")) icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.Vpn;
                        else if (mod.ModuleName.Contains("FTP")) icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.FolderNetwork;
                        else if (mod.ModuleName.Contains("SMB")) icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.ServerNetwork;
                        else if (mod.ModuleName.Contains("MySQL")) icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.DatabaseSearch;
                        else if (mod.ModuleName.Contains("OpenSSH")) icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.Console;
                        else icon.Kind = MaterialDesignThemes.Wpf.PackIconKind.Security;
                        
                        Grid.SetColumn(icon, 0);
                        grid.Children.Add(icon);

                        // Text
                        var spText = new StackPanel { Margin = new Thickness(10, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
                        var txtName = new TextBlock { Text = mod.ModuleName, FontSize = 16, FontWeight = FontWeights.Bold, Foreground = Brushes.White };
                        var txtSource = new TextBlock { Text = mod.LogSource, FontSize = 10, Foreground = Brushes.Gray, TextWrapping = TextWrapping.Wrap };
                        spText.Children.Add(txtName);
                        spText.Children.Add(txtSource);
                        Grid.SetColumn(spText, 1);
                        grid.Children.Add(spText);

                        // Controls
                        var spControls = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
                        
                        // Toggle (Using CheckBox as Toggle fallback for now, styled simply)
                        var toggle = new CheckBox 
                        { 
                            IsChecked = mod.IsActiveBool, 
                            Margin = new Thickness(0,0,10,0),
                            VerticalAlignment = VerticalAlignment.Center,
                            ToolTip = "Aktif/Pasif"
                        };
                        // Bind IsChecked to Module? No, manual handling for now or Binding in code
                        // Binding approach:
                        var binding = new System.Windows.Data.Binding("IsActiveBool") { Source = mod, Mode = System.Windows.Data.BindingMode.TwoWay };
                        toggle.SetBinding(CheckBox.IsCheckedProperty, binding);

                        // Settings Button
                        var btnSettings = new Button
                        {
                            Width = 30, Height=30,
                            Background = Brushes.Transparent,
                            BorderBrush = Brushes.Transparent,
                            Foreground = Brushes.Gray,
                            Tag = mod,
                            Padding = new Thickness(0)
                        };
                        btnSettings.Content = new MaterialDesignThemes.Wpf.PackIcon { Kind = MaterialDesignThemes.Wpf.PackIconKind.Cog, Width=20, Height=20 };
                        btnSettings.Click += BtnModuleSettings_Click;

                        spControls.Children.Add(toggle);
                        spControls.Children.Add(btnSettings);
                        Grid.SetColumn(spControls, 2);
                        grid.Children.Add(spControls);

                        border.Child = grid;
                        PanelModules.Children.Add(border);
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Modül Yükleme ui hatası: " + ex.Message); }
        }

        private void InitializeGateControl()
        {
            if (ToggleGeoMode != null)
            {
                ToggleGeoMode.IsChecked = _gateConfig.IsGeoWhitelistMode;
                UpdateGeoUiState();
            }
        }

        private async void BtnSaveModules_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string activeNames = "";
                using (var conn = DatabaseManager.GetConnection())
                {
                    conn.Open();
                    foreach (var mod in ModulesList)
                    {
                        string sql = "UPDATE Modules SET IsActive=@act, BlockLimit=@blim, AlertLimit=@alim WHERE Id=@id";
                        using (var cmd = new SQLiteCommand(sql, conn))
                        {
                            cmd.Parameters.AddWithValue("@act", mod.IsActive);
                            cmd.Parameters.AddWithValue("@blim", mod.BlockLimit);
                            cmd.Parameters.AddWithValue("@alim", mod.AlertLimit);
                            cmd.Parameters.AddWithValue("@id", mod.Id);
                            cmd.ExecuteNonQuery();
                        }
                        if (mod.IsActiveBool) activeNames += mod.ModuleName + " ";
                    }
                }

                if (TxtActiveModules != null) TxtActiveModules.Text = string.IsNullOrEmpty(activeNames) ? "YOK" : activeNames;
                if (_client != null && _client.IsConnected) await _client.WriteAsync(new SimsekMessage { Text = "REFRESH_MODULES" });
                MainSnackbar.MessageQueue?.Enqueue("TÜM MODÜLLER AKTİF EDİLDİ VE SERVİSE İLETİLDİ!");
            }
            catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
        }

        private void ToggleGeoMode_Checked(object sender, RoutedEventArgs e) { _gateConfig.IsGeoWhitelistMode = ToggleGeoMode.IsChecked == true; Simsek.Core.ConfigManager.Save(_gateConfig); UpdateGeoUiState(); }
        private void UpdateGeoUiState()
        {
            if (_gateConfig.IsGeoWhitelistMode) { 
                _visibleGeoList = new ObservableCollection<string>(_gateConfig.GeoWhitelist); 
                if(TxtDescBlacklistMode != null) { TxtDescBlacklistMode.Text = "WHITELIST"; TxtDescBlacklistMode.Foreground = System.Windows.Media.Brushes.Green; }
            }
            else { 
                _visibleGeoList = new ObservableCollection<string>(_gateConfig.GeoBlacklist); 
                if(TxtDescBlacklistMode != null) { TxtDescBlacklistMode.Text = "BLACKLIST"; TxtDescBlacklistMode.Foreground = System.Windows.Media.Brushes.Red; }
            }
            if (ListGeoCountries != null) ListGeoCountries.ItemsSource = _visibleGeoList;
        }
        private void BtnGeoEkle_Click(object sender, RoutedEventArgs e)
        {
            string c = TxtGeoInput.Text.ToUpper().Trim(); if (string.IsNullOrEmpty(c)) return;
            if (_gateConfig.IsGeoWhitelistMode) { if (!_gateConfig.GeoWhitelist.Contains(c)) { _gateConfig.GeoWhitelist.Add(c); _visibleGeoList.Add(c); } }
            else { if (!_gateConfig.GeoBlacklist.Contains(c)) { _gateConfig.GeoBlacklist.Add(c); _visibleGeoList.Add(c); } }
            ConfigManager.Save(_gateConfig); TxtGeoInput.Clear();
        }
        private void BtnGeoSil_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as System.Windows.Controls.Button)?.Tag is string country)
            {
                if (_gateConfig.IsGeoWhitelistMode) _gateConfig.GeoWhitelist.Remove(country); else _gateConfig.GeoBlacklist.Remove(country);
                _visibleGeoList.Remove(country);
                Simsek.Core.ConfigManager.Save(_gateConfig);
            }
        }

        // --- LİSTE İŞLEMLERİ (BLACKLIST & WHITELIST) ---

        private void BtnBlacklistAc_Click(object sender, RoutedEventArgs e)
        {
            _isEditingBlacklist = true;
            var dbBannedIps = DatabaseManager.GetAllBannedIps();
            _currentEditingBlacklist = new ObservableCollection<BannedItem>(dbBannedIps);
            TxtOverlayTitle.Text = "BLACKLIST";
            GridIpList.ItemsSource = _currentEditingBlacklist;
            OverlayListEdit.Visibility = Visibility.Visible;
        }


        private void BtnWhitelistAc_Click(object sender, RoutedEventArgs e)
        {
            _isEditingBlacklist = false;
            // DÜZELTME 2: Whitelist string listesini Grid'in anlayacağı BannedItem nesnelerine çeviriyoruz.
            _currentEditingWhitelist = new ObservableCollection<BannedItem>(
                _gateConfig.IpWhitelist.Select(ip => new BannedItem { Ip = ip, Country = "Güvenli", Reason = "Whitelist", BanDate = DateTime.Now })
            );

            TxtOverlayTitle.Text = "WHITELIST";
            GridIpList.ItemsSource = _currentEditingWhitelist; // Artık Grid dolu görünecek
            OverlayListEdit.Visibility = Visibility.Visible;
        }

        private void BtnOverlayClose_Click(object sender, RoutedEventArgs e)
        {
            if (_isEditingBlacklist)
            {
                _gateConfig.IpBlacklist = _currentEditingBlacklist.ToList();
                // FirewallHelper.SyncBlacklist(_gateConfig.IpBlacklist); // REMOVED: Service handles this
            }
            else
            {
                _gateConfig.IpWhitelist = _currentEditingWhitelist.Select(x => x.Ip).ToList();
            }
            Simsek.Core.ConfigManager.Save(_gateConfig);
            
            // Notify Service to Reload Rules
            if (_client != null && _client.IsConnected) 
                _ = _client.WriteAsync(new SimsekMessage { Text = "REFRESH_RULES" });
            
            OverlayListEdit.Visibility = Visibility.Collapsed;
        }

        private void BtnIpEkle_Click(object sender, RoutedEventArgs e)
        {
            string ip = TxtIpInput.Text.Trim();
            if (string.IsNullOrEmpty(ip)) return;

            try
            {
                if (_isEditingBlacklist)
                {
                    // 1. Whitelist kontrolü
                    if (_currentEditingWhitelist.Any(x => x.Ip == ip))
                    {
                        MainSnackbar.MessageQueue?.Enqueue($"{ip} WHITELIST'TE MEVCUT! ÖNCE ORADAN SİLİN.");
                        return;
                    }

                    // 2. Blacklist mükerrer kontrolü
                    if (_currentEditingBlacklist.Any(x => x.Ip == ip))
                    {
                        MainSnackbar.MessageQueue?.Enqueue($"{ip} ZATEN LİSTEDE!");
                        return;
                    }

                    var newItem = new BannedItem { Ip = ip, Country = "TR", BanDate = DateTime.Now, Reason = "Manuel Ekleme" };
                    _currentEditingBlacklist.Add(newItem);
                    _gateConfig.IpBlacklist.Add(newItem);
                    
                    // Veritabanına da ekle
                    DatabaseManager.InsertBannedIp(ip, "TR", "Manuel Ekleme");

                    MainSnackbar.MessageQueue?.Enqueue($"{ip} VERİTABANINA EKLENDİ! SERVİSE BİLDİRİLİYOR...");
                }
                else
                {
                    // 1. Blacklist kontrolü (Varsa çıkartalım)
                    var existingBan = _currentEditingBlacklist.FirstOrDefault(x => x.Ip == ip);
                    if (existingBan != null)
                    {
                        _currentEditingBlacklist.Remove(existingBan);
                        var confItem = _gateConfig.IpBlacklist.FirstOrDefault(x => x.Ip == ip);
                        if (confItem != null) _gateConfig.IpBlacklist.Remove(confItem);
                        
                        // DB'den de sil
                        DatabaseManager.DeleteBannedIp(ip);
                        
                        MainSnackbar.MessageQueue?.Enqueue($"{ip} BLACKLIST'TEN ÇIKARILDI VE WHITELIST'E EKLENDİ.");
                    }

                    if (!_currentEditingWhitelist.Any(x => x.Ip == ip))
                    {
                        var whiteItem = new BannedItem { Ip = ip, Country = "-", Reason = "Güvenli", BanDate = DateTime.Now };
                        _currentEditingWhitelist.Add(whiteItem);
                        _gateConfig.IpWhitelist.Add(ip);
                        MainSnackbar.MessageQueue?.Enqueue($"{ip} GÜVENLİ LİSTEYE ALINDI!");
                    }
                }
                Simsek.Core.ConfigManager.Save(_gateConfig);
                
                // Notify Service
                if (_client != null && _client.IsConnected) 
                    _ = _client.WriteAsync(new SimsekMessage { Text = "REFRESH_RULES" });

                TxtIpInput.Clear();
            }
            catch (Exception ex) { MessageBox.Show("Ekleme Hatası: " + ex.Message); }
        }

        private void BtnIpSil_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as System.Windows.Controls.Button;
            var item = btn?.Tag as BannedItem;

            if (item == null) return;

            try
            {
                if (_isEditingBlacklist)
                {
                    _currentEditingBlacklist.Remove(item);
                    var configItem = _gateConfig.IpBlacklist.FirstOrDefault(x => x.Ip == item.Ip);
                    if (configItem != null) _gateConfig.IpBlacklist.Remove(configItem);
                    
                    // Update Windows Firewall
                    try
                    {
                        FirewallHelper.SyncBlacklist(_gateConfig.IpBlacklist);
                        
                        // DB'den de sil
                        DatabaseManager.DeleteBannedIp(item.Ip);

                        System.Diagnostics.Debug.WriteLine($"Firewall updated: {item.Ip} removed");
                    }
                    catch (Exception fwEx)
                    {
                        System.Diagnostics.Debug.WriteLine($"Firewall update error: {fwEx.Message}");
                    }
                    
                    MainSnackbar.MessageQueue?.Enqueue($"{item.Ip} ENGELİ KALDIRILDI!");
                }
                else
                {
                    _currentEditingWhitelist.Remove(item);
                    _gateConfig.IpWhitelist.Remove(item.Ip);
                    MainSnackbar.MessageQueue?.Enqueue($"{item.Ip} WHITELIST'TEN ÇIKARILDI!");
                }
                Simsek.Core.ConfigManager.Save(_gateConfig);

                // Notify Service
                if (_client != null && _client.IsConnected) 
                    _ = _client.WriteAsync(new SimsekMessage { Text = "REFRESH_RULES" });
            }
            catch (Exception ex) { MessageBox.Show("Silme Hatası: " + ex.Message); }
        }

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<string> satirlar = new List<string>();

                if (_isEditingBlacklist)
                {
                    if (_gateConfig.IpBlacklist != null)
                    {
                        satirlar = _gateConfig.IpBlacklist
                            .Select(x => $"IP: {x.Ip} | Ülke: {x.Country} | Sebep: {x.Reason} | Tarih: {x.BanDate}")
                            .ToList();
                    }
                }
                else
                {
                    if (_gateConfig.IpWhitelist != null)
                    {
                        satirlar = _gateConfig.IpWhitelist.ToList();
                    }
                }

                if (satirlar.Count == 0)
                {
                    MessageBox.Show("Liste şu an boş, aktaracak bir şey yok!", "Bilgi", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                string listeTuru = _isEditingBlacklist ? "Blacklist" : "Whitelist";
                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "Text file (*.txt)|*.txt",
                    FileName = $"Simsek_{listeTuru}_{DateTime.Now:yyyyMMdd_HHmm}.txt"
                };

                if (sfd.ShowDialog() == true)
                {
                    File.WriteAllLines(sfd.FileName, satirlar);
                    MainSnackbar.MessageQueue?.Enqueue($"{listeTuru} BAŞARIYLA DIŞA AKTARILDI! ({satirlar.Count} KAYIT)");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Dışa aktarma hatası: " + ex.Message);
            }
        }

        private void BtnRaporAl_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string path = ReportManager.GenerateSummaryReport(1);
                MainSnackbar.MessageQueue?.Enqueue("RAPOR OLUŞTURULDU: " + Path.GetFileName(path));
                
                // Raporu açmak ister misin?
                if (MessageBox.Show("Rapor başarıyla oluşturuldu.\nAçmak ister misiniz?\n" + path, "Rapor Hazır", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
                {
                    new Process { StartInfo = new ProcessStartInfo(path) { UseShellExecute = true } }.Start();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Rapor Hatası: " + ex.Message);
            }
        }

        private void BtnManualBlock_Click(object sender, RoutedEventArgs e) { if ((sender as System.Windows.Controls.Button)?.Tag is string ip) BlockUser(ip, "Bilinmiyor", "Manuel"); }

        private void MenuDegisti(object sender, RoutedEventArgs e)
        {
            try
            {
                string icerik = (sender as System.Windows.Controls.RadioButton).Content.ToString();
                System.Diagnostics.Debug.WriteLine($"MenuDegisti: Switching to {icerik}");
                
                if (icerik == "DASHBOARD") MainTabControl.SelectedIndex = 0;
                else if (icerik == "GATE CONTROL") MainTabControl.SelectedIndex = 1;
                else if (icerik == "LIVE LOGS")
                {
                    System.Diagnostics.Debug.WriteLine("MenuDegisti: Loading Live Logs tab...");
                    MainTabControl.SelectedIndex = 2;
                    
                    // Lazy load logs only when tab is first accessed
                    if (!_logsLoaded)
                    {
                        System.Diagnostics.Debug.WriteLine("MenuDegisti: First time loading logs...");
                        LoadAllLogs();
                        _logsLoaded = true;
                        System.Diagnostics.Debug.WriteLine("MenuDegisti: Logs loaded successfully");
                    }
                }
                else if (icerik == "KORUMA MODÜLLERİ") 
            {
                MainTabControl.SelectedIndex = 3;
                LoadModulesFromDb(); // Refresh on click
                MessageBox.Show("Koruma Modülleri Sayfası Açıldı.", "Info", MessageBoxButton.OK, MessageBoxImage.Information); 
            }
                else if (icerik == "SMTP & ALERTS")
                {
                    MainTabControl.SelectedIndex = 4;
                    LoadSmtpUi();
                }
                else if (icerik == "HAKKINDA") MainTabControl.SelectedIndex = 5;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"MenuDegisti ERROR: {ex.Message}");
                MessageBox.Show($"Menü değiştirme hatası:\n{ex.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void BtnLink_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as System.Windows.Controls.Button)?.Tag is string url)
            {
                try 
                { 
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = url,
                        UseShellExecute = true
                    });
                }
                catch (Exception ex) { MessageBox.Show("Link açma hatası: " + ex.Message); }
            }
        }

        private void LoadSmtpUi()
        {
            var pConfig = ConfigManager.LoadProtectionConfig();
            TxtSmtpHost.Text = pConfig.SmtpHost;
            TxtSmtpPort.Text = pConfig.SmtpPort.ToString();
            TxtSmtpUser.Text = pConfig.SmtpUser;
            TxtSmtpPass.Password = pConfig.SmtpPass;
            ToggleSmtpSsl.IsChecked = pConfig.SmtpSsl;
            TxtFromEmail.Text = pConfig.FromEmail;
            TxtToEmail.Text = pConfig.ToEmail;

            ChkAlertOnBlock.IsChecked = pConfig.AlertOnBlock;
            ChkAlertOnGeoFail.IsChecked = pConfig.AlertOnGeoFail;
            ChkAlertOnGeoSuccess.IsChecked = pConfig.AlertOnGeoSuccess;
            ChkAlertOnCriticalModule.IsChecked = pConfig.AlertOnCriticalModule;

            // Load Task Settings
            SetComboValue(ComboReportFreq, pConfig.ReportFrequency);
            SetComboValue(ComboDbFreq, pConfig.DbMaintenanceFrequency);
        }

        private void SetComboValue(ComboBox combo, string value)
        {
            if (combo == null) return;
            foreach (ComboBoxItem item in combo.Items)
            {
                if (item.Tag.ToString() == value)
                {
                    combo.SelectedItem = item;
                    break;
                }
            }
        }

        public void BtnSaveSmtp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var pConfig = ConfigManager.LoadProtectionConfig();
                pConfig.SmtpHost = TxtSmtpHost.Text;
                pConfig.SmtpPort = int.Parse(TxtSmtpPort.Text);
                pConfig.SmtpUser = TxtSmtpUser.Text;
                pConfig.SmtpPass = TxtSmtpPass.Password;
                pConfig.SmtpSsl = ToggleSmtpSsl.IsChecked == true;
                pConfig.FromEmail = TxtFromEmail.Text;
                pConfig.ToEmail = TxtToEmail.Text;

                ConfigManager.SaveProtectionConfig(pConfig);
                MainSnackbar.MessageQueue?.Enqueue("SMTP AYARLARI KAYDEDİLDİ!");
            }
            catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
        }

        public void BtnSaveScenarios_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var pConfig = ConfigManager.LoadProtectionConfig();
                pConfig.AlertOnBlock = ChkAlertOnBlock.IsChecked == true;
                pConfig.AlertOnGeoFail = ChkAlertOnGeoFail.IsChecked == true;
                pConfig.AlertOnGeoSuccess = ChkAlertOnGeoSuccess.IsChecked == true;
                pConfig.AlertOnCriticalModule = ChkAlertOnCriticalModule.IsChecked == true;

                ConfigManager.SaveProtectionConfig(pConfig);
                MainSnackbar.MessageQueue?.Enqueue("ALERT SENARYOLARI GÜNCELLENDİ!");
            }
            catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
        }

        public async void BtnTestMail_Click(object sender, RoutedEventArgs e)
        {
            var pConfig = ConfigManager.LoadProtectionConfig();
            if (string.IsNullOrEmpty(pConfig.ToEmail))
            {
                MessageBox.Show("Önce alıcı email adresini girip kaydedin!");
                return;
            }

            MainSnackbar.MessageQueue?.Enqueue("TEST MAİLİ GÖNDERİLİYOR...");
            
            string testEmailBody = $@"Simsek Security - SMTP Yapılandırma Testi

Sayın Yönetici,

Bu e-posta, Simsek Security sisteminin SMTP yapılandırmasını doğrulamak amacıyla gönderilmiştir.

SMTP Sunucu Bilgileri:
- Sunucu: {pConfig.SmtpHost}
- Port: {pConfig.SmtpPort}
- SSL/TLS: {(pConfig.SmtpSsl ? "Aktif" : "Pasif")}
- Gönderen: {pConfig.FromEmail}
- Alıcı: {pConfig.ToEmail}

Bu mesajı aldıysanız, e-posta bildirim sisteminiz başarıyla yapılandırılmıştır ve güvenlik uyarıları düzenli olarak tarafınıza iletilecektir.

---
Simsek Security System
Tarih: {DateTime.Now:dd.MM.yyyy HH:mm:ss}
Sunucu: {Environment.MachineName}";

            await AlertManager.SendAlertAsync(pConfig, "Simsek Security - SMTP Yapılandırma Testi", testEmailBody);
            MainSnackbar.MessageQueue?.Enqueue("TEST MAİLİ GÖNDERİLDİ! Lütfen kutunuzu kontrol edin.");
        }


        private void UstBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) { if (e.ButtonState == MouseButtonState.Pressed) this.DragMove(); }
        private void BtnClose_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();
        private async void MainWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e) { if (_client != null) await _client.DisposeAsync(); }

        // --- YENİ LOG DETAY PENCERESİ MANTIĞI ---
        private void BtnShowLog_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as System.Windows.Controls.Button)?.Tag is AttackLog log)
            {
                TxtFullLogContent.Text = log.FullMessage;
                OverlayLogDetail.Visibility = Visibility.Visible;
            }
        }

        private void BtnCloseLogDetail_Click(object sender, RoutedEventArgs e)
        {
            OverlayLogDetail.Visibility = Visibility.Collapsed;
        }

        public void ComboLogFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyLogFilter();
        }

        private void TxtLogSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyLogFilter();
        }

        private void ApplyLogFilter()
        {
             if (GridAllLogs == null || AllLogsList == null) return;

             string typeFilter = "";
             if (ComboLogFilter != null && ComboLogFilter.SelectedItem is ComboBoxItem item)
             {
                 typeFilter = item.Content?.ToString() ?? "Tümü";
             }
             if (typeFilter == "Tümü") typeFilter = "";

             string searchText = TxtLogSearch?.Text?.Trim() ?? "";

             if (string.IsNullOrEmpty(typeFilter) && string.IsNullOrEmpty(searchText))
             {
                 GridAllLogs.ItemsSource = AllLogsList;
             }
             else
             {
                 var filtered = AllLogsList.Where(x => 
                     (string.IsNullOrEmpty(typeFilter) || (x.EventType != null && x.EventType.Contains(typeFilter, StringComparison.OrdinalIgnoreCase)) || (x.Service != null && x.Service.Contains(typeFilter, StringComparison.OrdinalIgnoreCase))) &&
                     (string.IsNullOrEmpty(searchText) || 
                         (x.AttackerIp != null && x.AttackerIp.Contains(searchText, StringComparison.OrdinalIgnoreCase)) ||
                         (x.AttackerCountry != null && x.AttackerCountry.Contains(searchText, StringComparison.OrdinalIgnoreCase)) ||
                         (x.FullMessage != null && x.FullMessage.Contains(searchText, StringComparison.OrdinalIgnoreCase)) ||
                         (x.TargetUsername != null && x.TargetUsername.Contains(searchText, StringComparison.OrdinalIgnoreCase))
                     )
                 ).ToList();
                 GridAllLogs.ItemsSource = filtered;
             }
        }

        private void BtnTopCountry_Click(object sender, RoutedEventArgs e)
        {
             if ((sender as System.Windows.Controls.Button)?.Tag is string country)
             {
                 // 1. Switch Tab
                 MainTabControl.SelectedIndex = 2;
                 
                 // 2. Load Logs if needed
                 if (!_logsLoaded) { LoadAllLogs(); _logsLoaded = true; }

                 // 3. Set Filter
                 if (TxtLogSearch != null)
                 {
                     TxtLogSearch.Text = country;
                     // TextChanged will trigger ApplyLogFilter
                 }
             }
        }

        public void BtnExportPdf_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Mevcut görünen listeyi gönder
                var listToExport = GridAllLogs.ItemsSource as IEnumerable<AttackLog>;
                if (listToExport == null || !listToExport.Any())
                {
                    MessageBox.Show("Listede veri yok!");
                    return;
                }

                string path = ReportManager.GenerateLogListReport(listToExport.ToList());
                MainSnackbar.MessageQueue?.Enqueue("PDF OLUŞTURULDU: " + Path.GetFileName(path));
                
                if (MessageBox.Show("PDF Raporu açmak ister misiniz?\n" + path, "Rapor Hazır", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    new Process { StartInfo = new ProcessStartInfo(path) { UseShellExecute = true } }.Start();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PDF Hatası: " + ex.Message);
            }
        }

        public async void BtnEmailReport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var pConfig = ConfigManager.LoadProtectionConfig();
                if (string.IsNullOrEmpty(pConfig.ToEmail))
                {
                    MessageBox.Show("Önce SMTP ayarlarını yapın!");
                    return;
                }

                // Mevcut görünen listeyi gönder
                var listToExport = GridAllLogs.ItemsSource as IEnumerable<AttackLog>;
                if (listToExport == null || !listToExport.Any())
                {
                    MessageBox.Show("Listede veri yok!");
                    return;
                }

                MainSnackbar.MessageQueue?.Enqueue("RAPOR OLUŞTURULUYOR VE GÖNDERİLİYOR...");

                string path = await Task.Run(() => ReportManager.GenerateLogListReport(listToExport.ToList()));
                
                await AlertManager.SendAlertAsync(pConfig, "Simsek Security - Log Raporu", "İstediğiniz log raporu ektedir.", path);
                
                MainSnackbar.MessageQueue?.Enqueue("RAPOR BAŞARIYLA GÖNDERİLDİ!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Mail Gönderme Hatası: " + ex.Message);
            }
        }

        public async void BtnSaveTasks_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var pConfig = ConfigManager.LoadProtectionConfig();
                
                if (ComboReportFreq.SelectedItem is ComboBoxItem itemReport) pConfig.ReportFrequency = itemReport.Tag.ToString();
                if (ComboDbFreq.SelectedItem is ComboBoxItem itemDb) pConfig.DbMaintenanceFrequency = itemDb.Tag.ToString();

                ConfigManager.SaveProtectionConfig(pConfig);
                
                // Notify Service
                if (_client != null && _client.IsConnected) await _client.WriteAsync(new SimsekMessage { Text = "REFRESH_SETTINGS" });

                MainSnackbar.MessageQueue?.Enqueue("ZAMANLANMIŞ GÖREV AYARLARI KAYDEDİLDİ!");
            }
            catch (Exception ex) { MessageBox.Show("Kaydetme Hatası: " + ex.Message); }
        }
        
        // DATABASE MANAGEMENT HELPERS
        private void CleanAllLogs()
        {
            try
            {
                var result = MessageBox.Show("Tüm logları silmek istediğinize emin misiniz?", 
                    "Onay", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                
                if (result == MessageBoxResult.Yes)
                {
                    using (var conn = DatabaseManager.GetConnection())
                    {
                        conn.Open();
                        
                        var cmd = new SQLiteCommand("DELETE FROM AttackLogs", conn);
                        int deleted = cmd.ExecuteNonQuery();
                        
                        cmd = new SQLiteCommand("DELETE FROM sqlite_sequence WHERE name='AttackLogs'", conn);
                        cmd.ExecuteNonQuery();
                        
                        MessageBox.Show($"{deleted} log silindi!", "Başarılı", MessageBoxButton.OK, MessageBoxImage.Information);
                        
                        // Refresh UI
                        if (AllLogsList != null)
                        {
                            AllLogsList.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hata: {ex.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void AddSampleLogs()
        {
            try
            {
                var samples = new List<AttackLog>
                {
                    new AttackLog { Time = DateTime.Parse("2026-02-08 15:30:00"), AttackerIp = "192.168.1.100", AttackerCountry = "TR", Service = "RDP", FullMessage = "Failed RDP login attempt", TargetUsername = "administrator", EventType = "Brute Force", IsBlocked = true },
                    new AttackLog { Time = DateTime.Parse("2026-02-08 15:31:15"), AttackerIp = "45.142.212.61", AttackerCountry = "RU", Service = "MSSQL", FullMessage = "SQL authentication failure", TargetUsername = "sa", EventType = "SQL Injection", IsBlocked = true },
                    new AttackLog { Time = DateTime.Parse("2026-02-08 15:32:30"), AttackerIp = "103.75.32.18", AttackerCountry = "CN", Service = "RDP", FullMessage = "Multiple failed login attempts", TargetUsername = "admin", EventType = "Brute Force", IsBlocked = true },
                    new AttackLog { Time = DateTime.Parse("2026-02-08 15:33:45"), AttackerIp = "185.220.101.42", AttackerCountry = "DE", Service = "FTP", FullMessage = "FTP brute force detected", TargetUsername = "ftpuser", EventType = "FTP Attack", IsBlocked = false },
                    new AttackLog { Time = DateTime.Parse("2026-02-08 15:35:00"), AttackerIp = "198.51.100.23", AttackerCountry = "US", Service = "SSH", FullMessage = "SSH authentication failure", TargetUsername = "root", EventType = "SSH Brute Force", IsBlocked = true }
                };
                
                foreach (var log in samples)
                {
                    DatabaseManager.InsertAttackLog(log, log.IsBlocked);
                }
                
                MessageBox.Show($"{samples.Count} örnek log eklendi!", "Başarılı", MessageBoxButton.OK, MessageBoxImage.Information);
                
                // Refresh logs
                LoadAllLogs();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hata: {ex.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        // BUTTON EVENT HANDLERS FOR DATABASE MANAGEMENT
        private void BtnCleanLogs_Click(object sender, RoutedEventArgs e)
        {
            CleanAllLogs();
        }
        
        private void BtnAddSample_Click(object sender, RoutedEventArgs e)
        {
            AddSampleLogs();
        }

        private void BtnRefreshHost_Click(object sender, RoutedEventArgs e)
        {
            LoadHostInfo();
        }

        private void LoadProfilePhoto()
        {
            try
            {
                // Try multiple possible locations and formats
                string[] possiblePaths = new[]
                {
                    System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "profile_photo.jpg"),
                    System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "profile.jpg"),
                    System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "profile.png"),
                    System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "profile.jpg")
                };

                string foundPath = null;
                foreach (var path in possiblePaths)
                {
                    if (System.IO.File.Exists(path))
                    {
                        foundPath = path;
                        break;
                    }
                }

                if (foundPath != null)
                {
                    var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri(foundPath);
                    bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad; // Unlock file after load
                    bitmap.EndInit();

                    if (ProfileImageBrush != null) ProfileImageBrush.ImageSource = bitmap;
                    if (ProfileIcon != null) ProfileIcon.Visibility = Visibility.Collapsed;
                    if (ProfilePhotoContainer != null) ProfilePhotoContainer.Visibility = Visibility.Visible;
                    
                    System.Diagnostics.Debug.WriteLine($"Profile photo loaded from: {foundPath}");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("Profile photo not found. Using default icon.");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Profile Photo Load Error: " + ex.Message);
            }
        }
        private void ApplyLanguage()
        {
            var loc = Simsek.Core.LocalizationManager.Instance;

            // Dashboard DataGrid Columns
            if (GridLiveTraffic != null && GridLiveTraffic.Columns.Count >= 8)
            {
                GridLiveTraffic.Columns[0].Header = loc.GetString("col_time", "ZAMAN");
                GridLiveTraffic.Columns[1].Header = loc.GetString("col_machine_name", "PC ADI");
                GridLiveTraffic.Columns[2].Header = loc.GetString("col_machine_ip", "PC IP");
                GridLiveTraffic.Columns[3].Header = loc.GetString("col_event", "OLAY");
                GridLiveTraffic.Columns[4].Header = loc.GetString("col_service", "SERVİS");
                GridLiveTraffic.Columns[5].Header = loc.GetString("col_source", "KAYNAK");
                GridLiveTraffic.Columns[6].Header = loc.GetString("col_country", "ÜLKE");
                GridLiveTraffic.Columns[7].Header = loc.GetString("col_target_user", "HEDEF USER");
                if(GridLiveTraffic.Columns.Count > 8) GridLiveTraffic.Columns[8].Header = loc.GetString("col_detail", "DETAY");
            }

            // --- GATE CONTROL ---
            if(TxtHeaderGeoControl != null) TxtHeaderGeoControl.Text = loc.GetString("header_geo_control", "COĞRAFİ KONTROL");
            if(TxtDescBlacklistMode != null) TxtDescBlacklistMode.Text = loc.GetString("desc_blacklist_mode", "BLACKLIST MODU");
            if(TxtGeoInput != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtGeoInput, loc.GetString("hint_country_code", "Ülke Kodu"));
            if(BtnGeoAdd != null) BtnGeoAdd.Content = loc.GetString("btn_add", "EKLE");
            
            if(TxtHeaderLastAccess != null) TxtHeaderLastAccess.Text = loc.GetString("header_last_access", "SON ERİŞİM AKTİVİTELERİ");
            
            // Gate Logs Columns
            if (GridGateLogs != null && GridGateLogs.Columns.Count >= 6)
            {
                GridGateLogs.Columns[0].Header = loc.GetString("col_time", "ZAMAN");
                GridGateLogs.Columns[1].Header = loc.GetString("col_ip", "IP");
                GridGateLogs.Columns[2].Header = loc.GetString("col_country", "ÜLKE");
                GridGateLogs.Columns[3].Header = loc.GetString("col_service", "SERVİS");
                GridGateLogs.Columns[4].Header = loc.GetString("col_event", "OLAY");
                GridGateLogs.Columns[5].Header = loc.GetString("col_action", "İŞLEM");
            }
            
            if(TxtHeaderBlacklist != null) TxtHeaderBlacklist.Text = loc.GetString("header_blacklist", "BLACKLIST");
            if(TxtDescBlacklist != null) TxtDescBlacklist.Text = loc.GetString("desc_blacklist", "Kalıcı olarak engellenenler.");
            if(BtnEditBlacklist != null) BtnEditBlacklist.Content = loc.GetString("btn_edit", "DÜZENLE");
            
            if(TxtHeaderWhitelist != null) TxtHeaderWhitelist.Text = loc.GetString("header_whitelist", "WHITELIST");
            if(TxtDescWhitelist != null) TxtDescWhitelist.Text = loc.GetString("desc_whitelist", "Asla engellenmeyecekler.");
            if(BtnEditWhitelist != null) BtnEditWhitelist.Content = loc.GetString("btn_edit", "DÜZENLE");

            // --- LIVE LOGS ---
            if(TxtHeaderLiveLogs != null) TxtHeaderLiveLogs.Text = loc.GetString("header_live_logs", "CANLI LOG KAYITLARI");
            if(TxtLogSearch != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtLogSearch, loc.GetString("hint_log_search", "Ara..."));
            if(ComboLogFilter != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(ComboLogFilter, loc.GetString("hint_log_filter", "Olay Tipi"));
            if(ComboLogFilter != null && ComboLogFilter.Items.Count > 0) ((ComboBoxItem)ComboLogFilter.Items[0]).Content = loc.GetString("combo_all", "Tümü");
            
            if(BtnDownloadPdf != null) 
            {
                // Access TextBlock inside Button Template? Hard. Assuming Content is accessible or handled. 
                // Since ContentTemplate is used, Content property might be ignored or used as context.
                // In XAML: <Button Content="PDF İNDİR" ...> <TextBlock Text="PDF"/> </Template>
                // This is tricky. The TextBlock "PDF" is inside the template. The Button Content "PDF İNDİR" is used for other things?
                // Actually the XAML had <Button Content="PDF İNDİR"> but then <Button.ContentTemplate>... <TextBlock Text="PDF"/> ...
                // If ContentTemplate is set, the ContentPresenter uses it. The TextBlock text "PDF" is hardcoded in XAML template!
                // ERROR: I cannot change text inside a DataTemplate easily from code behind without finding the visual child.
                // BETTER: I'll rely on the ToolTip or just accept "PDF" is universal.
                // However, the Button's "Content" property IS set to "PDF İNDİR". 
                // Let's assume the user accepts "PDF" and "MAIL" as icons. 
                // But the user said "Tüm metinleri çevir".
                // I will update the Button's Content.
                BtnDownloadPdf.Content = loc.GetString("btn_download_pdf", "PDF İNDİR");
                BtnSendMail.Content = loc.GetString("btn_send_mail", "MAİL GÖNDER");
            }

            // All Logs Columns
            if(GridAllLogs != null && GridAllLogs.Columns.Count >= 7)
            {
                GridAllLogs.Columns[0].Header = loc.GetString("col_time", "ZAMAN");
                GridAllLogs.Columns[1].Header = loc.GetString("col_service", "SERVİS");
                GridAllLogs.Columns[2].Header = loc.GetString("col_event_type", "OLAY TİPİ");
                GridAllLogs.Columns[3].Header = loc.GetString("col_attacker_ip", "SALDIRGAN IP");
                GridAllLogs.Columns[4].Header = loc.GetString("col_country", "ÜLKE");
                GridAllLogs.Columns[5].Header = loc.GetString("col_target_user", "HEDEF USER");
                GridAllLogs.Columns[6].Header = loc.GetString("col_detail", "DETAY");
            }

            // --- MODULES ---
            if(TxtHeaderModules != null) TxtHeaderModules.Text = loc.GetString("header_modules", "KORUMA MODÜLLERİ");
            if(BtnSaveModules != null) BtnSaveModules.Content = loc.GetString("btn_save_modules", "DEĞİŞİKLİKLERİ UYGULA");

            // --- SMTP & ALERTS ---
            if(TxtHeaderSmtp != null) TxtHeaderSmtp.Text = loc.GetString("header_smtp", "SMTP AYARLARI");
            if(TxtSmtpHost != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtSmtpHost, loc.GetString("hint_smtp_host"));
            if(TxtSmtpPort != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtSmtpPort, loc.GetString("hint_smtp_port"));
            if(TxtSmtpUser != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtSmtpUser, loc.GetString("hint_smtp_user"));
            if(TxtSmtpPass != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtSmtpPass, loc.GetString("hint_smtp_pass"));
            if(TxtSslActive != null) TxtSslActive.Text = loc.GetString("txt_ssl_active", "SSL/TLS Aktif");
            if(TxtFromEmail != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtFromEmail, loc.GetString("hint_from_email"));
            if(TxtToEmail != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtToEmail, loc.GetString("hint_to_email"));
            if(BtnSaveSmtp != null) BtnSaveSmtp.Content = loc.GetString("btn_save_smtp", "KAYDET");

            if(TxtHeaderAlerts != null) TxtHeaderAlerts.Text = loc.GetString("header_alerts", "ALERT SENARYOLARI");
            if(ChkAlertOnBlock != null) ChkAlertOnBlock.Content = loc.GetString("chk_alert_block");
            if(ChkAlertOnGeoFail != null) ChkAlertOnGeoFail.Content = loc.GetString("chk_alert_geo_fail");
            if(ChkAlertOnGeoSuccess != null) ChkAlertOnGeoSuccess.Content = loc.GetString("chk_alert_geo_success");
            if(ChkAlertOnCriticalModule != null) ChkAlertOnCriticalModule.Content = loc.GetString("chk_alert_critical");
            if(BtnSaveScenarios != null) BtnSaveScenarios.Content = loc.GetString("btn_save_scenarios");
            if(BtnTestMail != null) BtnTestMail.Content = loc.GetString("btn_test_mail");

            // --- TASKS ---
            if(TxtHeaderTasks != null) TxtHeaderTasks.Text = loc.GetString("header_tasks", "ZAMANLANMIŞ GÖREVLER");
            if(LblAutoReport != null) LblAutoReport.Text = loc.GetString("lbl_auto_report");
            if(ComboReportFreq != null && ComboReportFreq.Items.Count >= 3)
            {
                ((ComboBoxItem)ComboReportFreq.Items[0]).Content = loc.GetString("combo_never");
                ((ComboBoxItem)ComboReportFreq.Items[1]).Content = loc.GetString("combo_weekly");
                ((ComboBoxItem)ComboReportFreq.Items[2]).Content = loc.GetString("combo_monthly");
            }
            if(LblDbMaint != null) LblDbMaint.Text = loc.GetString("lbl_db_maint");
            if(ComboDbFreq != null && ComboDbFreq.Items.Count >= 3)
            {
                ((ComboBoxItem)ComboDbFreq.Items[0]).Content = loc.GetString("combo_never");
                ((ComboBoxItem)ComboDbFreq.Items[1]).Content = loc.GetString("combo_weekly");
                ((ComboBoxItem)ComboDbFreq.Items[2]).Content = loc.GetString("combo_monthly");
            }
            if(BtnSaveTasks != null) BtnSaveTasks.Content = loc.GetString("btn_save_tasks");

            // --- ABOUT ---
            if(TxtAppTitle != null) TxtAppTitle.Text = loc.GetString("header_app_title", "ŞİMŞEK SECURITY V2");
            if(TxtAppDesc1 != null) TxtAppDesc1.Text = "Open Source HIPS Security Tool"; // Keep English
            if(TxtAppDesc2 != null) TxtAppDesc2.Text = loc.GetString("app_desc_2");
            if(TxtDeveloperTitle != null) TxtDeveloperTitle.Text = loc.GetString("title_developer");
            if(TxtCredits != null) TxtCredits.Text = loc.GetString("header_credits");
            if(TxtCreditsDesc != null) TxtCreditsDesc.Text = loc.GetString("desc_credits");

            
            // Combo Language Selection


            // --- OVERLAYS ---
            if(TxtOverlayTitle != null) TxtOverlayTitle.Text = loc.GetString("header_list", "LİSTE");
            if(TxtIpInput != null) MaterialDesignThemes.Wpf.HintAssist.SetHint(TxtIpInput, loc.GetString("hint_ip_input"));
            if(BtnOverlayAdd != null) BtnOverlayAdd.Content = loc.GetString("btn_add_list");
            
            if(GridIpList != null && GridIpList.Columns.Count >= 4)
            {
                GridIpList.Columns[0].Header = loc.GetString("col_ip_address");
                GridIpList.Columns[1].Header = loc.GetString("col_country");
                GridIpList.Columns[2].Header = loc.GetString("col_reason");
                GridIpList.Columns[3].Header = loc.GetString("col_date");
            }
            if(BtnExport != null) BtnExport.Content = loc.GetString("btn_export");

            if(TxtHeaderModuleSettings != null) TxtHeaderModuleSettings.Text = loc.GetString("header_module_settings");
            if(LblBanLimit != null) LblBanLimit.Text = loc.GetString("lbl_ban_limit");
            if(LblAlertLimit != null) LblAlertLimit.Text = loc.GetString("lbl_alert_limit");
            if(ChkForeignAlert != null) ChkForeignAlert.Content = loc.GetString("chk_foreign_alert");
            if(BtnCloseModuleSettings != null) BtnCloseModuleSettings.Content = loc.GetString("btn_ok");
            
            if(TxtHeaderLogDetail != null) TxtHeaderLogDetail.Text = loc.GetString("header_log_detail");
            if(BtnCloseLogDetailOverlay != null) BtnCloseLogDetailOverlay.Content = loc.GetString("btn_close");
        }

    }
}