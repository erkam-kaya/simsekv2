# Profile Photo Setup Instructions

To add your profile photo to the About page:

1. **Locate your profile photo** (the one from your ID or professional photo)

2. **Copy the photo** to one of these locations:
   - `Simsek.UI\Resources\profile_photo.jpg` (recommended)
   - `Simsek.UI\Resources\profile.jpg`
   - `Simsek.UI\Resources\profile.png`

3. **Rebuild the application** to include the photo in the output

4. **Run the application** and navigate to the "HAKKINDA" tab to see your photo

## Notes:
- The photo will be displayed in a circular frame
- Supported formats: JPG, PNG
- The application will automatically use the default icon if no photo is found
- The photo file will be copied to the output directory when you build the project
