# Add Sample Attack Logs
# Adds realistic sample data for testing

$dbPath = "$env:ProgramData\SimsekSecurity\SimsekV2.db"

Write-Host "=== Adding Sample Attack Logs ===" -ForegroundColor Cyan
Write-Host ""

if (!(Test-Path $dbPath)) {
    Write-Host "ERROR: Database not found!" -ForegroundColor Red
    exit 1
}

try {
    Add-Type -Path "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek.Core\bin\Debug\net8.0\System.Data.SQLite.dll"
    
    $conn = New-Object System.Data.SQLite.SQLiteConnection("Data Source=$dbPath;Version=3;")
    $conn.Open()
    
    Write-Host "Adding sample logs..." -ForegroundColor Yellow
    
    # Sample logs
    $samples = @(
        @{Time = "2026-02-08 15:30:00"; IP = "192.168.1.100"; Country = "TR"; Service = "RDP"; Details = "Failed RDP login attempt"; User = "administrator"; Blocked = 1 },
        @{Time = "2026-02-08 15:31:15"; IP = "45.142.212.61"; Country = "RU"; Service = "MSSQL"; Details = "SQL authentication failure"; User = "sa"; Blocked = 1 },
        @{Time = "2026-02-08 15:32:30"; IP = "103.75.32.18"; Country = "CN"; Service = "RDP"; Details = "Multiple failed login attempts"; User = "admin"; Blocked = 1 },
        @{Time = "2026-02-08 15:33:45"; IP = "185.220.101.42"; Country = "DE"; Service = "FTP"; Details = "FTP brute force detected"; User = "ftpuser"; Blocked = 0 },
        @{Time = "2026-02-08 15:35:00"; IP = "198.51.100.23"; Country = "US"; Service = "SSH"; Details = "SSH authentication failure"; User = "root"; Blocked = 1 }
    )
    
    foreach ($log in $samples) {
        $cmd = $conn.CreateCommand()
        $cmd.CommandText = @"
INSERT INTO AttackLogs (Timestamp, IpAddress, Country, Service, LogDetails, TargetUsername, IsBlocked)
VALUES (@time, @ip, @country, @service, @details, @user, @blocked)
"@
        $cmd.Parameters.AddWithValue("@time", $log.Time) | Out-Null
        $cmd.Parameters.AddWithValue("@ip", $log.IP) | Out-Null
        $cmd.Parameters.AddWithValue("@country", $log.Country) | Out-Null
        $cmd.Parameters.AddWithValue("@service", $log.Service) | Out-Null
        $cmd.Parameters.AddWithValue("@details", $log.Details) | Out-Null
        $cmd.Parameters.AddWithValue("@user", $log.User) | Out-Null
        $cmd.Parameters.AddWithValue("@blocked", $log.Blocked) | Out-Null
        
        $cmd.ExecuteNonQuery() | Out-Null
        Write-Host "  + Added $($log.Service) attack from $($log.Country)" -ForegroundColor Green
    }
    
    # Count total
    $cmd = $conn.CreateCommand()
    $cmd.CommandText = "SELECT COUNT(*) FROM AttackLogs"
    $total = $cmd.ExecuteScalar()
    
    $conn.Close()
    
    Write-Host ""
    Write-Host "Total logs in database: $total" -ForegroundColor Cyan
    Write-Host "Sample data added successfully!" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Read-Host "Press Enter to exit"
