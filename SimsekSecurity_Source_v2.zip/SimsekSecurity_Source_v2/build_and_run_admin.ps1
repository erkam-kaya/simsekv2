# Simsek HIPS - Build ve Yönetici Olarak Çalıştır
# Bu script build yapar ve yönetici yetkisiyle başlatır

Write-Host "=== Simsek HIPS - Build & Run Admin ===" -ForegroundColor Cyan
Write-Host ""

# 1. Tüm süreçleri kapat
Write-Host "Mevcut süreçler kapatılıyor..." -ForegroundColor Yellow
Get-Process | Where-Object { $_.ProcessName -match 'Simsek' } | Stop-Process -Force -ErrorAction SilentlyContinue
Write-Host "  + Süreçler kapatıldı" -ForegroundColor Green

# 2. Build
Write-Host ""
Write-Host "Build yapılıyor..." -ForegroundColor Yellow
dotnet build
if ($LASTEXITCODE -ne 0) {
    Write-Host "  ! Build başarısız!" -ForegroundColor Red
    Read-Host "Devam etmek için Enter'a basın"
    exit 1
}
Write-Host "  + Build başarılı" -ForegroundColor Green

# 3. Service'i başlat
Write-Host ""
Write-Host "Service başlatılıyor..." -ForegroundColor Yellow
$servicePath = ".\Simsek.Service\bin\Debug\net8.0\Simsek.Service.exe"
if (Test-Path $servicePath) {
    Start-Process -FilePath $servicePath -Verb RunAs -WindowStyle Hidden
    Write-Host "  + Service başlatıldı" -ForegroundColor Green
    Start-Sleep -Seconds 2
}
else {
    Write-Host "  ! Service bulunamadı" -ForegroundColor Red
}

# 4. UI'ı başlat
Write-Host ""
Write-Host "UI başlatılıyor..." -ForegroundColor Yellow
$uiPath = ".\Simsek.UI\bin\Debug\net8.0-windows\Simsek.UI.exe"
if (Test-Path $uiPath) {
    Start-Process -FilePath $uiPath -Verb RunAs
    Write-Host "  + UI başlatıldı" -ForegroundColor Green
}
else {
    Write-Host "  ! UI bulunamadı" -ForegroundColor Red
}

Write-Host ""
Write-Host "Tamamlandı!" -ForegroundColor Cyan
