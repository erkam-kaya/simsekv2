# Build Installer Script
# This script builds the Inno Setup installer for Simsek Security

$InnoSetupPath = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
$ScriptPath = "Simsek_Setup.iss"

Write-Host "Checking Inno Setup installation..." -ForegroundColor Cyan

if (-not (Test-Path $InnoSetupPath)) {
    Write-Host "ERROR: Inno Setup not found at: $InnoSetupPath" -ForegroundColor Red
    Write-Host "Please install Inno Setup 6 from: https://jrsoftware.org/isdl.php" -ForegroundColor Yellow
    exit 1
}

Write-Host "Inno Setup found!" -ForegroundColor Green
Write-Host "Building installer from: $ScriptPath" -ForegroundColor Cyan

& $InnoSetupPath $ScriptPath

if ($LASTEXITCODE -eq 0) {
    Write-Host "`nInstaller built successfully!" -ForegroundColor Green
    Write-Host "Output: Releases\SimsekSecurity_Setup_v2.0.exe" -ForegroundColor Cyan
} else {
    Write-Host "`nInstaller build FAILED!" -ForegroundColor Red
    exit $LASTEXITCODE
}
