# Database Schema Checker
$dbPath = "$env:ProgramData\SimsekSecurity\SimsekV2.db"

Write-Host "Checking database at: $dbPath" -ForegroundColor Cyan
Write-Host ""

if (!(Test-Path $dbPath)) {
    Write-Host "ERROR: Database not found!" -ForegroundColor Red
    exit 1
}

Write-Host "Database file exists ($(((Get-Item $dbPath).Length / 1KB).ToString('F2')) KB)" -ForegroundColor Green
Write-Host ""

# Load SQLite assembly
Add-Type -Path "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek.Core\bin\Debug\net8.0\System.Data.SQLite.dll"

try {
    $conn = New-Object System.Data.SQLite.SQLiteConnection("Data Source=$dbPath;Version=3;")
    $conn.Open()
    Write-Host "Connection opened successfully!" -ForegroundColor Green
    Write-Host ""
    
    # List tables
    $cmd = $conn.CreateCommand()
    $cmd.CommandText = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    $reader = $cmd.ExecuteReader()
    
    Write-Host "Tables in database:" -ForegroundColor Yellow
    while ($reader.Read()) {
        Write-Host "  - $($reader['name'])"
    }
    $reader.Close()
    Write-Host ""
    
    # Check AttackLogs structure
    $cmd.CommandText = "PRAGMA table_info(AttackLogs)"
    $reader = $cmd.ExecuteReader()
    
    Write-Host "AttackLogs table structure:" -ForegroundColor Yellow
    while ($reader.Read()) {
        Write-Host "  - $($reader['name']) ($($reader['type']))"
    }
    $reader.Close()
    Write-Host ""
    
    # Count records
    $cmd.CommandText = "SELECT COUNT(*) FROM AttackLogs"
    $count = $cmd.ExecuteScalar()
    Write-Host "Total AttackLogs records: $count" -ForegroundColor Cyan
    
    $conn.Close()
    Write-Host ""
    Write-Host "All checks passed!" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host $_.Exception.StackTrace
}
