# Database Cleanup Script
# Clears all test data from Simsek Security database

$dbPath = "$env:ProgramData\SimsekSecurity\SimsekV2.db"

Write-Host "=== Simsek Security Database Cleanup ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Database: $dbPath" -ForegroundColor Yellow
Write-Host ""

if (!(Test-Path $dbPath)) {
    Write-Host "ERROR: Database not found!" -ForegroundColor Red
    exit 1
}

$confirm = Read-Host "This will DELETE ALL logs. Continue? (yes/no)"
if ($confirm -ne "yes") {
    Write-Host "Cancelled." -ForegroundColor Yellow
    exit 0
}

try {
    Add-Type -Path "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek.Core\bin\Debug\net8.0\System.Data.SQLite.dll"
    
    $conn = New-Object System.Data.SQLite.SQLiteConnection("Data Source=$dbPath;Version=3;")
    $conn.Open()
    
    # Count before
    $cmd = $conn.CreateCommand()
    $cmd.CommandText = "SELECT COUNT(*) FROM AttackLogs"
    $countBefore = $cmd.ExecuteScalar()
    Write-Host "Logs before cleanup: $countBefore" -ForegroundColor Yellow
    
    # Delete all logs
    $cmd.CommandText = "DELETE FROM AttackLogs"
    $deleted = $cmd.ExecuteNonQuery()
    Write-Host "Deleted $deleted logs" -ForegroundColor Green
    
    # Reset auto-increment
    $cmd.CommandText = "DELETE FROM sqlite_sequence WHERE name='AttackLogs'"
    $cmd.ExecuteNonQuery()
    Write-Host "Reset ID counter" -ForegroundColor Green
    
    # Verify
    $cmd.CommandText = "SELECT COUNT(*) FROM AttackLogs"
    $countAfter = $cmd.ExecuteScalar()
    Write-Host "Logs after cleanup: $countAfter" -ForegroundColor Cyan
    
    $conn.Close()
    Write-Host ""
    Write-Host "Cleanup completed successfully!" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Read-Host "Press Enter to exit"
