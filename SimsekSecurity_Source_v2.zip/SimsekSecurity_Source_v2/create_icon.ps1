Add-Type -AssemblyName System.Drawing

$assetsPath = "Simsek.UI\Assets"
if (-not (Test-Path $assetsPath)) {
    New-Item -ItemType Directory -Path $assetsPath -Force | Out-Null
}

$iconPath = Join-Path $PWD "$assetsPath\simsek.ico"

try {
    $size = 256
    $bmp = [System.Drawing.Bitmap]::new($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias

    # Background - Dark Circle
    $rect = [System.Drawing.Rectangle]::new(0, 0, $size, $size)
    $brushBg = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 30, 30, 30))
    $g.FillEllipse($brushBg, $rect)

    # Lightning Bolt
    $points = @(
        [System.Drawing.PointF]::new(140, 20),
        [System.Drawing.PointF]::new(80, 140),
        [System.Drawing.PointF]::new(120, 140),
        [System.Drawing.PointF]::new(100, 240),
        [System.Drawing.PointF]::new(180, 110),
        [System.Drawing.PointF]::new(140, 110)
    )

    $brushBolt = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255, 255, 193, 7)) # Amber/Gold
    $g.FillPolygon($brushBolt, $points)

    # Border
    $pen = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(255, 255, 193, 7), 10)
    $g.DrawEllipse($pen, 10, 10, 236, 236)

    # Save as Icon
    $ms = [System.IO.MemoryStream]::new()
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $ms.Seek(0, [System.IO.SeekOrigin]::Begin)

    # Create File
    $iconStream = [System.IO.File]::Create($iconPath)
    $bw = [System.IO.BinaryWriter]::new($iconStream)

    # ICO Header
    $bw.Write([int16]0) # Reserved
    $bw.Write([int16]1) # Type (1=Icon)
    $bw.Write([int16]1) # Count
    # Icon Directory Entry
    $bw.Write([byte]0); $bw.Write([byte]0); $bw.Write([byte]0); $bw.Write([byte]0)
    $bw.Write([int16]1); $bw.Write([int16]32); $bw.Write([int32]$ms.Length); $bw.Write([int32]22)
    # Image Data
    $bw.Write($ms.ToArray())

    $bw.Close()
    $iconStream.Close()
    $ms.Close()
    $bmp.Dispose()
    $g.Dispose()

    Write-Host "SUCCESS: Icon created at $iconPath" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Stack Trace: $($_.Exception.StackTrace)" -ForegroundColor Red
    exit 1
}
