
$dbPath = "C:\ProgramData\SimsekSecurity\SimsekV2.db"
$dllPath = "$PSScriptRoot\Simsek.UI\bin\Debug\net8.0-windows\System.Data.SQLite.dll"

Write-Host "Database: $dbPath"
Write-Host "DLL: $dllPath"

if (-not (Test-Path $dllPath)) {
    Write-Error "DLL not found!"
    exit
}

Add-Type -Path $dllPath

$connStr = "Data Source=$dbPath;Version=3;"
$conn = New-Object System.Data.SQLite.SQLiteConnection($connStr)

try {
    $conn.Open()
    Write-Host "Connection Opened."
    
    $cmd = $conn.CreateCommand()
    $cmd.CommandText = "SELECT * FROM Modules"
    $reader = $cmd.ExecuteReader()
    
    if (-not $reader.HasRows) {
        Write-Host "Table 'Modules' is EMPTY."
    } else {
        Write-Host "--- MODULES ---"
        while ($reader.Read()) {
            $name = $reader["ModuleName"]
            $active = $reader["IsActive"]
            Write-Host "Module: $name | Active: $active"
        }
    }
} catch {
    Write-Error $_
} finally {
    $conn.Close()
    Write-Host "Connection Closed."
}
