# Otomatik Kurulum ve Sıfırlama Scripti
# Bu script tüm değişiklikleri otomatik olarak uygular

$ErrorActionPreference = "Continue"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  SİMŞEK SECURITY - OTOMATIK KURULUM" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

$projectRoot = "C:\Users\ErkamKaya\source\repos\SimsekSecurity"
$photoSource = ""
$photoDestination = "$projectRoot\Simsek.UI\Resources\profile_photo.jpg"

# ADIM 1: Profil Fotoğrafını Bul ve Kopyala
Write-Host "[1/4] Profil fotoğrafı aranıyor..." -ForegroundColor Cyan

# Masaüstünde jpg dosyalarını ara
$desktopPhotos = Get-ChildItem "$env:USERPROFILE\Desktop\*.jpg" -ErrorAction SilentlyContinue
if ($desktopPhotos) {
    Write-Host "  Masaüstünde $($desktopPhotos.Count) adet JPG dosyası bulundu:" -ForegroundColor Yellow
    for ($i = 0; $i -lt $desktopPhotos.Count; $i++) {
        Write-Host "  [$i] $($desktopPhotos[$i].Name)" -ForegroundColor Gray
    }
    
    if ($desktopPhotos.Count -eq 1) {
        $photoSource = $desktopPhotos[0].FullName
        Write-Host "  -> Tek fotoğraf bulundu, otomatik seçildi: $($desktopPhotos[0].Name)" -ForegroundColor Green
    }
    else {
        $selection = Read-Host "  Hangi fotoğrafı kullanmak istersiniz? (0-$($desktopPhotos.Count-1) veya tam yol)"
        if ($selection -match '^\d+$' -and [int]$selection -lt $desktopPhotos.Count) {
            $photoSource = $desktopPhotos[[int]$selection].FullName
        }
        else {
            $photoSource = $selection
        }
    }
    
    if (Test-Path $photoSource) {
        Copy-Item -Path $photoSource -Destination $photoDestination -Force
        Write-Host "  -> Fotoğraf kopyalandı: $photoDestination" -ForegroundColor Green
    }
    else {
        Write-Host "  -> UYARI: Fotoğraf bulunamadı, varsayılan ikon kullanılacak" -ForegroundColor Yellow
    }
}
else {
    Write-Host "  -> UYARI: Masaüstünde fotoğraf bulunamadı" -ForegroundColor Yellow
    Write-Host "  -> Manuel olarak eklemek için: $photoDestination" -ForegroundColor Gray
}

Write-Host ""

# ADIM 2: Uygulamayı Yeniden Derle
Write-Host "[2/4] Uygulama derleniyor..." -ForegroundColor Cyan

cd $projectRoot
$buildResult = dotnet build Simsek.UI\Simsek.UI.csproj --configuration Debug 2>&1

if ($LASTEXITCODE -eq 0) {
    Write-Host "  -> Derleme başarılı!" -ForegroundColor Green
}
else {
    Write-Host "  -> HATA: Derleme başarısız!" -ForegroundColor Red
    Write-Host $buildResult -ForegroundColor Gray
}

Write-Host ""

# ADIM 3: Veritabanını Sıfırla
Write-Host "[3/4] Veritabanı sıfırlanıyor..." -ForegroundColor Cyan

$resetConfirm = Read-Host "  Veritabanını sıfırlamak istiyor musunuz? (E/H)"
if ($resetConfirm -eq "E" -or $resetConfirm -eq "e") {
    Write-Host "  -> Reset scripti çalıştırılıyor..." -ForegroundColor Yellow
    
    # Reset scriptini çağır
    & "$projectRoot\reset_database.ps1" -Confirm:$false
    
    Write-Host "  -> Veritabanı sıfırlandı!" -ForegroundColor Green
}
else {
    Write-Host "  -> Veritabanı sıfırlama atlandı" -ForegroundColor Yellow
}

Write-Host ""

# ADIM 4: Özet
Write-Host "[4/4] Kurulum Özeti" -ForegroundColor Cyan
Write-Host ""

if (Test-Path $photoDestination) {
    Write-Host "  ✓ Profil fotoğrafı: HAZIR" -ForegroundColor Green
}
else {
    Write-Host "  ✗ Profil fotoğrafı: YOK (varsayılan ikon kullanılacak)" -ForegroundColor Yellow
}

if ($LASTEXITCODE -eq 0) {
    Write-Host "  ✓ Uygulama derlemesi: BAŞARILI" -ForegroundColor Green
}
else {
    Write-Host "  ✗ Uygulama derlemesi: BAŞARISIZ" -ForegroundColor Red
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  KURULUM TAMAMLANDI!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Uygulamayı başlatmak için:" -ForegroundColor Cyan
Write-Host "  cd Simsek.UI\bin\Debug\net8.0-windows" -ForegroundColor White
Write-Host "  .\Simsek.UI.exe" -ForegroundColor White
Write-Host ""
Write-Host "veya Visual Studio'dan F5 ile çalıştırın." -ForegroundColor Gray
Write-Host ""

Read-Host "Devam etmek için Enter'a basın"
