# Simsek Security - Complete Database Reset Script
# This script resets the database to a clean state with NO sample data
# WARNING: This will DELETE ALL data including logs, SMTP settings, blacklists, etc.

$ErrorActionPreference = "Stop"

$dbPath = "$env:ProgramData\SimsekSecurity\SimsekV2.db"
$dbFolder = "$env:ProgramData\SimsekSecurity"
$serviceName = "SimsekService"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  SIMSEK SECURITY - DATABASE RESET TOOL" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "WARNING: This will DELETE ALL data!" -ForegroundColor Red
Write-Host "  - All attack logs" -ForegroundColor Yellow
Write-Host "  - SMTP settings" -ForegroundColor Yellow
Write-Host "  - Blacklist/Whitelist entries" -ForegroundColor Yellow
Write-Host "  - Alert configurations" -ForegroundColor Yellow
Write-Host "  - Module settings" -ForegroundColor Yellow
Write-Host ""
Write-Host "Database location: $dbPath" -ForegroundColor Gray
Write-Host ""

# Confirm action
$confirmation = Read-Host "Type 'RESET' to continue or anything else to cancel"
if ($confirmation -ne "RESET") {
    Write-Host "Operation cancelled." -ForegroundColor Yellow
    exit 0
}

Write-Host ""
Write-Host "[1/5] Checking service status..." -ForegroundColor Cyan

# Check if service exists and stop it
try {
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service) {
        if ($service.Status -eq "Running") {
            Write-Host "  -> Stopping $serviceName..." -ForegroundColor Yellow
            Stop-Service -Name $serviceName -Force
            Start-Sleep -Seconds 2
            Write-Host "  -> Service stopped" -ForegroundColor Green
        } else {
            Write-Host "  -> Service already stopped" -ForegroundColor Green
        }
    } else {
        Write-Host "  -> Service not found (OK)" -ForegroundColor Gray
    }
} catch {
    Write-Host "  -> Warning: Could not stop service: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "[2/5] Deleting existing database..." -ForegroundColor Cyan

# Delete database file if it exists
if (Test-Path $dbPath) {
    try {
        Remove-Item -Path $dbPath -Force
        Write-Host "  -> Database file deleted" -ForegroundColor Green
    } catch {
        Write-Host "  -> ERROR: Could not delete database: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "  -> Make sure the application is closed and try again" -ForegroundColor Yellow
        exit 1
    }
} else {
    Write-Host "  -> Database file not found (will create new)" -ForegroundColor Gray
}

# Delete WAL and SHM files if they exist
$walPath = "$dbPath-wal"
$shmPath = "$dbPath-shm"
if (Test-Path $walPath) { Remove-Item -Path $walPath -Force }
if (Test-Path $shmPath) { Remove-Item -Path $shmPath -Force }

Write-Host ""
Write-Host "[3/5] Creating fresh database..." -ForegroundColor Cyan

# Ensure folder exists
if (!(Test-Path $dbFolder)) {
    New-Item -ItemType Directory -Path $dbFolder -Force | Out-Null
}

# Load SQLite assembly
try {
    $sqliteDllPath = "C:\Users\ErkamKaya\source\repos\SimsekSecurity\Simsek.Core\bin\Debug\net8.0\System.Data.SQLite.dll"
    if (Test-Path $sqliteDllPath) {
        Add-Type -Path $sqliteDllPath
    } else {
        Write-Host "  -> ERROR: SQLite DLL not found at: $sqliteDllPath" -ForegroundColor Red
        Write-Host "  -> Please build the project first" -ForegroundColor Yellow
        exit 1
    }
} catch {
    Write-Host "  -> ERROR: Could not load SQLite: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Create new database file
[System.Data.SQLite.SQLiteConnection]::CreateFile($dbPath)
Write-Host "  -> Database file created" -ForegroundColor Green

# Create connection and tables
$connectionString = "Data Source=$dbPath;Version=3;Journal Mode=WAL;"
$conn = New-Object System.Data.SQLite.SQLiteConnection($connectionString)
$conn.Open()

Write-Host "  -> Creating tables..." -ForegroundColor Yellow

# Create Modules table
$cmd = $conn.CreateCommand()
$cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Modules (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    ModuleName TEXT UNIQUE, 
    LogType TEXT,
    LogSource TEXT,
    DetectionPattern TEXT,
    BlockLimit INTEGER DEFAULT 7,
    AlertLimit INTEGER DEFAULT 5,
    IsActive INTEGER DEFAULT 1
)
"@
$cmd.ExecuteNonQuery() | Out-Null

# Create AttackLogs table
$cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS AttackLogs (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    IpAddress TEXT,
    Country TEXT,
    Service TEXT,
    LogDetails TEXT,
    TargetUsername TEXT,
    IsBlocked INTEGER DEFAULT 0
)
"@
$cmd.ExecuteNonQuery() | Out-Null

# Create BannedIps table
$cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS BannedIps (
    IpAddress TEXT PRIMARY KEY,
    Country TEXT,
    Reason TEXT,
    BanDate DATETIME DEFAULT CURRENT_TIMESTAMP
)
"@
$cmd.ExecuteNonQuery() | Out-Null

# Create Settings table
$cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Settings (
    Key TEXT PRIMARY KEY, 
    Value TEXT
)
"@
$cmd.ExecuteNonQuery() | Out-Null

# Enable WAL mode
$cmd.CommandText = "PRAGMA journal_mode=WAL;"
$cmd.ExecuteNonQuery() | Out-Null

Write-Host "  -> Tables created successfully" -ForegroundColor Green

Write-Host ""
Write-Host "[4/5] Initializing default modules (INACTIVE)..." -ForegroundColor Cyan

# Insert default modules (all INACTIVE - IsActive=0)
$modules = @(
    @{Name="RDP"; Type="EventLog"; Source="Security"; Pattern="EventID=4625"; Block=7; Alert=3},
    @{Name="MSSQL"; Type="EventLog"; Source="Application"; Pattern="EventID=18456"; Block=10; Alert=5},
    @{Name="IIS"; Type="FileLog"; Source="C:\inetpub\logs\LogFiles"; Pattern=" 403 "; Block=50; Alert=20},
    @{Name="VPN"; Type="EventLog"; Source="Security"; Pattern="EventID=6273"; Block=5; Alert=2},
    @{Name="FTP"; Type="FileLog"; Source="C:\inetpub\logs\LogFiles\FTPSVC"; Pattern=" 530 "; Block=10; Alert=5},
    @{Name="SMB"; Type="EventLog"; Source="Security"; Pattern="EventID=4625"; Block=10; Alert=5},
    @{Name="MySQL"; Type="FileLog"; Source="C:\ProgramData\MySQL\MySQL Server 8.0\Data\mysqld.log"; Pattern="Access denied"; Block=10; Alert=5},
    @{Name="OpenSSH"; Type="EventLog"; Source="OpenSSH/Operational"; Pattern="EventID=4"; Block=5; Alert=3}
)

foreach ($module in $modules) {
    $cmd.CommandText = @"
INSERT INTO Modules (ModuleName, LogType, LogSource, DetectionPattern, BlockLimit, AlertLimit, IsActive) 
VALUES (@name, @type, @src, @pat, @blim, @alim, 0)
"@
    $cmd.Parameters.Clear()
    $cmd.Parameters.AddWithValue("@name", $module.Name) | Out-Null
    $cmd.Parameters.AddWithValue("@type", $module.Type) | Out-Null
    $cmd.Parameters.AddWithValue("@src", $module.Source) | Out-Null
    $cmd.Parameters.AddWithValue("@pat", $module.Pattern) | Out-Null
    $cmd.Parameters.AddWithValue("@blim", $module.Block) | Out-Null
    $cmd.Parameters.AddWithValue("@alim", $module.Alert) | Out-Null
    $cmd.ExecuteNonQuery() | Out-Null
    Write-Host "  -> Added module: $($module.Name) (INACTIVE)" -ForegroundColor Gray
}

$conn.Close()
Write-Host "  -> Modules initialized" -ForegroundColor Green

Write-Host ""
Write-Host "[5/5] Restarting service..." -ForegroundColor Cyan

# Restart service if it was running
try {
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service) {
        Write-Host "  -> Starting $serviceName..." -ForegroundColor Yellow
        Start-Service -Name $serviceName
        Start-Sleep -Seconds 2
        $service = Get-Service -Name $serviceName
        if ($service.Status -eq "Running") {
            Write-Host "  -> Service started successfully" -ForegroundColor Green
        } else {
            Write-Host "  -> Warning: Service did not start" -ForegroundColor Yellow
        }
    }
} catch {
    Write-Host "  -> Warning: Could not start service: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "  DATABASE RESET COMPLETED SUCCESSFULLY!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "Database is now in CLEAN STATE:" -ForegroundColor Cyan
Write-Host "  - 0 attack logs" -ForegroundColor White
Write-Host "  - 0 SMTP settings" -ForegroundColor White
Write-Host "  - 0 blacklist/whitelist entries" -ForegroundColor White
Write-Host "  - 8 default modules (ALL INACTIVE)" -ForegroundColor White
Write-Host ""
Write-Host "You can now start the application with a fresh database." -ForegroundColor Yellow
Write-Host ""
Read-Host "Press Enter to exit"
