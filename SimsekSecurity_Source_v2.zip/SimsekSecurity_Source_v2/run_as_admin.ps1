# Simsek HIPS - Yönetici Olarak Çalıştır
# Bu script hem Service hem de UI'ı yönetici yetkisiyle başlatır

Write-Host "=== Simsek HIPS - Admin Mode ===" -ForegroundColor Cyan
Write-Host ""

# 1. Service'i başlat
Write-Host "Service başlatılıyor..." -ForegroundColor Yellow
try {
    $servicePath = ".\Simsek.Service\bin\Debug\net8.0\Simsek.Service.exe"
    if (Test-Path $servicePath) {
        Start-Process -FilePath $servicePath -Verb RunAs -WindowStyle Hidden
        Write-Host "  + Service başlatıldı" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    else {
        Write-Host "  ! Service bulunamadı, önce build edin" -ForegroundColor Red
    }
}
catch {
    Write-Host "  ! Service başlatılamadı: $($_.Exception.Message)" -ForegroundColor Red
}

# 2. UI'ı başlat
Write-Host "UI başlatılıyor..." -ForegroundColor Yellow
try {
    $uiPath = ".\Simsek.UI\bin\Debug\net8.0-windows\Simsek.UI.exe"
    if (Test-Path $uiPath) {
        Start-Process -FilePath $uiPath -Verb RunAs
        Write-Host "  + UI başlatıldı" -ForegroundColor Green
    }
    else {
        Write-Host "  ! UI bulunamadı, önce build edin" -ForegroundColor Red
    }
}
catch {
    Write-Host "  ! UI başlatılamadı: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "Tamamlandı!" -ForegroundColor Cyan
