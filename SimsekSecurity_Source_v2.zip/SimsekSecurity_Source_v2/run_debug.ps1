$ErrorActionPreference = "Continue"
$logFile = "ui_crash_log.txt"

Write-Host "Starting Simsek UI with full error logging..." -ForegroundColor Cyan
Write-Host "Log file: $logFile" -ForegroundColor Yellow
Write-Host ""

# Clear old log
if (Test-Path $logFile) { Remove-Item $logFile }

# Run with error redirection
dotnet run --project Simsek.UI/Simsek.UI.csproj 2>&1 | Tee-Object -FilePath $logFile

Write-Host ""
Write-Host "Application closed. Exit code: $LASTEXITCODE" -ForegroundColor $(if ($LASTEXITCODE -eq 0) { "Green" } else { "Red" })
Write-Host ""
Write-Host "=== Last 50 lines of log ===" -ForegroundColor Yellow
Get-Content $logFile -Tail 50
Write-Host ""
Write-Host "Full log saved to: $logFile" -ForegroundColor Cyan
Write-Host ""
Read-Host "Press Enter to exit"
