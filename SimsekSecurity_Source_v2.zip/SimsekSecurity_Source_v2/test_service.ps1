# Service Test Script
Write-Host "`n=== Simsek Security Service Test ===" -ForegroundColor Cyan

# 1. Service durumunu kontrol et
Write-Host "`n1. Service Durumu:" -ForegroundColor Yellow
$service = Get-Service SimsekService -ErrorAction SilentlyContinue
if ($service) {
    if ($service.Status -eq 'Running') {
        Write-Host "   ✓ Service ÇALIŞIYOR" -ForegroundColor Green
    }
    else {
        Write-Host "   ✗ Service DURMUŞ" -ForegroundColor Red
    }
    Write-Host "   StartType: $($service.StartType)" -ForegroundColor Cyan
}
else {
    Write-Host "   ✗ Service bulunamadı!" -ForegroundColor Red
}

# 2. Veritabanı kontrolü
Write-Host "`n2. Veritabanı:" -ForegroundColor Yellow
$dbPath = "C:\ProgramData\SimsekSecurity\SimsekV2.db"
if (Test-Path $dbPath) {
    Write-Host "   ✓ Veritabanı mevcut" -ForegroundColor Green
}
else {
    Write-Host "   ✗ Veritabanı bulunamadı!" -ForegroundColor Red
}

# 3. Log dosyaları
Write-Host "`n3. Log Dosyaları:" -ForegroundColor Yellow
$logFolder = "C:\ProgramData\SimsekSecurity"
if (Test-Path $logFolder) {
    $files = Get-ChildItem $logFolder -File
    if ($files) {
        foreach ($file in $files) {
            Write-Host "   - $($file.Name)" -ForegroundColor Cyan
        }
    }
    else {
        Write-Host "   (Henüz log yok)" -ForegroundColor Gray
    }
}
else {
    Write-Host "   ✗ Klasör bulunamadı!" -ForegroundColor Red
}

Write-Host "`n=== Test Tamamlandı ===" -ForegroundColor Cyan
